#!/usr/bin/env python
# -*- coding: utf-8 -*-

import errno
import fcntl
import os
import shutil
import threading
import time
import uuid
from types import MappingProxyType

from .artifacts import (
    archive_file,
    archive_open_file,
    preflight_artifact,
    read_json,
    validate_artifact,
    write_json_atomic,
)
from .errors import FLRuntimeError


class WorkDirLock(object):
    def __init__(self, work_dir):
        os.makedirs(work_dir, exist_ok=True)
        lock_path = os.path.join(work_dir, 'runtime.lock')
        self._lock_file = None
        try:
            self._lock_file = open(lock_path, 'a+b')
        except OSError as exc:
            raise FLRuntimeError(
                'work_dir_unavailable', '无法打开 Runtime 工作目录锁') from exc
        try:
            fcntl.flock(
                self._lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self._lock_file.close()
            self._lock_file = None
            if exc.errno in (errno.EACCES, errno.EAGAIN):
                raise FLRuntimeError(
                    'work_dir_locked',
                    '工作目录已被其他 Runtime 实例占用') from exc
            raise FLRuntimeError(
                'work_dir_unavailable', '无法取得 Runtime 工作目录锁') from exc

    def close(self):
        if self._lock_file is None:
            return
        fcntl.flock(self._lock_file.fileno(), fcntl.LOCK_UN)
        self._lock_file.close()
        self._lock_file = None

    def __del__(self):
        self.close()


def _validate_max_update_size(value):
    if type(value) is not int or value <= 0:
        raise FLRuntimeError('invalid_configuration', 'update 大小限制无效')


def _parse_round_id(value):
    if not isinstance(value, str):
        raise FLRuntimeError('invalid_manifest', '轮次标识无效')
    try:
        parsed = uuid.UUID(value)
    except (ValueError, TypeError, AttributeError) as exc:
        raise FLRuntimeError('invalid_manifest', '轮次标识无效') from exc
    if parsed.version != 4 or str(parsed) != value:
        raise FLRuntimeError('invalid_manifest', '轮次标识无效')
    return value


def _validate_sha256(value):
    if (not isinstance(value, str) or len(value) != 64 or
            any(character not in '0123456789abcdef' for character in value)):
        raise FLRuntimeError('invalid_manifest', 'SHA-256 摘要无效')


def _validate_exact_fields(value, fields):
    if not isinstance(value, dict) or set(value) != set(fields):
        raise FLRuntimeError('invalid_manifest', 'manifest 字段无效')


def validate_round_state(state, round_id, role, active_states):
    terminal_states = ('succeeded', 'failed')
    if (not isinstance(state, dict) or
            type(state.get('schema_version')) is not int or
            state.get('schema_version') != 1 or
            state.get('round_id') != round_id or
            state.get('role') != role or
            state.get('state') not in active_states + terminal_states):
        raise FLRuntimeError('round_state_corrupted', '轮次状态结构无效')
    if state['state'] == 'succeeded' and role == 'server':
        participant_node_ids = state.get('participant_node_ids')
        committed_node_ids = state.get('committed_update_node_ids')
        if (not isinstance(participant_node_ids, list) or
                any(type(node_id) is not int or node_id <= 0
                    for node_id in participant_node_ids) or
                participant_node_ids != sorted(set(participant_node_ids)) or
                not isinstance(committed_node_ids, list) or
                any(type(node_id) is not int or node_id <= 0
                    for node_id in committed_node_ids) or
                committed_node_ids != sorted(set(committed_node_ids)) or
                len(committed_node_ids) == 0 or
                not set(committed_node_ids).issubset(set(participant_node_ids))):
            raise FLRuntimeError('round_state_corrupted', '成功轮次参与集合无效')
    diagnostics = state.get('downlink_diagnostics')
    if ('downlink_diagnostics' in state and state['state'] != 'failed'):
        raise FLRuntimeError('round_state_corrupted', '下行诊断状态无效')
    if state['state'] == 'failed':
        if (not isinstance(state.get('error_code'), str) or
                not state['error_code'] or
                not isinstance(state.get('error_message'), str)):
            raise FLRuntimeError('round_state_corrupted', '失败轮次错误无效')
        node_id = state.get('node_id')
        if node_id is not None and (type(node_id) is not int or node_id <= 0):
            raise FLRuntimeError('round_state_corrupted', '失败轮次节点标识无效')
        diagnostics = state.get('downlink_diagnostics')
        if 'downlink_diagnostics' in state:
            _validate_downlink_diagnostics(diagnostics, role)


def _validate_downlink_diagnostics(value, role):
    allowed_fields = {'natural_result', 'cancel_result', 'cancel_error'}
    if (role != 'server' or not isinstance(value, dict) or not value or
            not set(value).issubset(allowed_fields)):
        raise FLRuntimeError('round_state_corrupted', '下行诊断结构无效')
    natural_result = value.get('natural_result')
    if 'natural_result' in value:
        if natural_result == 'succeeded':
            pass
        elif (not isinstance(natural_result, dict) or
              set(natural_result) != {'error_code', 'error_message'} or
              not isinstance(natural_result['error_code'], str) or
              not natural_result['error_code'] or
              not isinstance(natural_result['error_message'], str)):
            raise FLRuntimeError('round_state_corrupted', '下行自然结果无效')
    cancel_result = value.get('cancel_result')
    cancel_error = value.get('cancel_error')
    if ('cancel_result' in value and cancel_result not in (
            'cancelled', 'already_completed')):
        raise FLRuntimeError('round_state_corrupted', '下行取消结果无效')
    if 'cancel_error' in value:
        if (not isinstance(cancel_error, dict) or
                set(cancel_error) != {'exception_type', 'message'} or
                not isinstance(cancel_error['exception_type'], str) or
                not cancel_error['exception_type'] or
                not isinstance(cancel_error['message'], str)):
            raise FLRuntimeError('round_state_corrupted', '下行取消异常无效')
    if cancel_result is not None and cancel_error is not None:
        raise FLRuntimeError('round_state_corrupted', '下行取消诊断冲突')


def recover_round_states(work_dir, role):
    rounds_dir = os.path.join(work_dir, 'rounds')
    try:
        names = os.listdir(rounds_dir)
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise FLRuntimeError(
            'round_state_corrupted', '无法扫描轮次状态') from exc

    active_states = {
        'server': ('publishing_model', 'waiting_for_updates'),
        'client': ('model_received', 'submitting_update'),
    }
    terminal_states = ('succeeded', 'failed')
    terminal_by_id = {}
    restarted = []
    for name in names:
        round_dir = os.path.join(rounds_dir, name)
        if not os.path.isdir(round_dir):
            raise FLRuntimeError('round_state_corrupted', '轮次目录结构无效')
        try:
            round_id = str(uuid.UUID(name))
        except (ValueError, TypeError, AttributeError) as exc:
            raise FLRuntimeError('round_state_corrupted', '轮次目录标识无效') from exc
        if round_id != name:
            raise FLRuntimeError('round_state_corrupted', '轮次目录标识无效')
        state_path = os.path.join(round_dir, 'round-state.json')
        try:
            state = read_json(state_path)
        except FLRuntimeError as exc:
            raise FLRuntimeError('round_state_corrupted', '无法读取轮次状态') from exc
        validate_round_state(state, round_id, role, active_states[role])
        if state['state'] in terminal_states:
            terminal_by_id[round_id] = state
            continue
        previous_state = state['state']
        state.update({
            'state': 'failed',
            'error_code': 'runtime_restarted',
            'error_message': 'Runtime 重启终结了未完成轮次',
            'restart_previous_state': previous_state,
        })
        write_json_atomic(state_path, state)
        terminal_by_id[round_id] = state
        restarted.append(state)

    current_path = os.path.join(work_dir, 'current-round.json')
    if not os.path.exists(current_path):
        if len(restarted) == 1:
            return restarted[0]
        if len(restarted) > 1:
            raise FLRuntimeError(
                'round_state_corrupted', '无法确定重启前当前轮次')
        return None
    try:
        current = read_json(current_path)
        round_id = str(uuid.UUID(current['round_id']))
    except (FLRuntimeError, KeyError, ValueError, TypeError, AttributeError) as exc:
        raise FLRuntimeError('round_state_corrupted', '当前轮次指针无效') from exc
    if current != {
            'schema_version': 1, 'role': role, 'round_id': round_id}:
        raise FLRuntimeError('round_state_corrupted', '当前轮次指针无效')
    try:
        return terminal_by_id[round_id]
    except KeyError as exc:
        raise FLRuntimeError('round_state_corrupted', '当前轮次状态不存在') from exc


def write_current_round(work_dir, role, round_id):
    write_json_atomic(os.path.join(work_dir, 'current-round.json'), {
        'schema_version': 1,
        'role': role,
        'round_id': round_id,
    })


class ServerRuntime(object):
    def __init__(self, work_dir, participant_node_ids, max_update_size_bytes, transport):
        self.work_dir = os.path.abspath(work_dir)
        if isinstance(participant_node_ids, int):
            participant_node_ids = (participant_node_ids,)
        participant_node_ids = tuple(participant_node_ids)
        if (not participant_node_ids or
                any(not isinstance(node_id, int) or isinstance(node_id, bool) or
                    node_id <= 0 for node_id in participant_node_ids) or
                len(set(participant_node_ids)) != len(participant_node_ids)):
            raise FLRuntimeError('invalid_configuration', '参与节点集合无效')
        self.participant_node_ids = tuple(sorted(participant_node_ids))
        _validate_max_update_size(max_update_size_bytes)
        self.max_update_size_bytes = max_update_size_bytes
        self.transport = transport
        self._owner = WorkDirLock(self.work_dir)
        try:
            recovered_state = recover_round_states(self.work_dir, 'server')
        except Exception:
            self._owner.close()
            raise
        self._condition = threading.Condition()
        self._fatal_error = None
        self._round_id = None
        self._round_dir = None
        self._downlink_completed = False
        self._failure = None
        self._state = None
        self._recovered_participant_node_ids = None
        self._round_result_consumed = False
        self._publish_active = False
        self._downlink_operation = None
        self._downlink_diagnostics = {}
        self._downlink_diagnostics_persistence_error = None
        self._downlink_cancel_active = False
        self._downlink_cancel_finished = False
        self._wait_for_updates_active = False
        if recovered_state is not None:
            self._restore_terminal_state(recovered_state)

    def close(self):
        self._owner.close()

    @property
    def round_id(self):
        with self._condition:
            return self._round_id

    def _restore_terminal_state(self, state):
        round_id = state['round_id']
        if state['state'] == 'succeeded':
            participant_node_ids = state.get('participant_node_ids')
            committed_node_ids = state.get('committed_update_node_ids')
            if (not isinstance(participant_node_ids, list) or
                    any(type(node_id) is not int or node_id <= 0
                        for node_id in participant_node_ids) or
                    participant_node_ids != sorted(set(participant_node_ids)) or
                    not isinstance(committed_node_ids, list) or
                    not committed_node_ids or
                    not set(committed_node_ids).issubset(set(participant_node_ids)) or
                    committed_node_ids != sorted(set(committed_node_ids))):
                self._owner.close()
                raise FLRuntimeError(
                    'round_state_corrupted', '成功轮次参与集合无效')
            self._recovered_participant_node_ids = tuple(participant_node_ids)
            self._downlink_completed = True
        elif state['state'] == 'failed':
            if (not isinstance(state.get('error_code'), str) or
                    not isinstance(state.get('error_message'), str)):
                self._owner.close()
                raise FLRuntimeError('round_state_corrupted', '失败轮次错误无效')
            self._failure = FLRuntimeError(
                state['error_code'], state['error_message'],
                round_id=round_id, node_id=state.get('node_id'))
            self._downlink_diagnostics = dict(
                state.get('downlink_diagnostics', {}))
        else:
            self._owner.close()
            raise FLRuntimeError('round_state_corrupted', '当前轮次不是终态')
        self._round_id = round_id
        self._round_dir = os.path.join(self.work_dir, 'rounds', round_id)
        self._state = state['state']

    def publish_model(self, model_path):
        self._require_ready()
        with self._condition:
            if self._publish_active:
                raise FLRuntimeError('operation_in_progress', '已有模型发布正在进行')
            if self._round_id is not None:
                if self._state in ('succeeded', 'failed'):
                    if not self._round_result_consumed:
                        raise FLRuntimeError('round_result_pending', '轮次结果尚未消费')
                else:
                    raise FLRuntimeError('round_in_progress', '已有活动轮次')
            self._publish_active = True

        try:
            return self._publish_model(model_path)
        finally:
            with self._condition:
                self._publish_active = False

    def _publish_model(self, model_path):
        source, source_stat = preflight_artifact(model_path)
        try:
            while True:
                round_id = str(uuid.uuid4())
                round_dir = os.path.join(self.work_dir, 'rounds', round_id)
                try:
                    os.makedirs(round_dir)
                    break
                except FileExistsError:
                    continue
            model_target = os.path.join(round_dir, 'model.bin')
            manifest_path = os.path.join(round_dir, 'model.manifest.json')

            with self._condition:
                self._round_id = round_id
                self._round_dir = round_dir
                self._downlink_completed = False
                self._failure = None
                self._downlink_diagnostics = {}
                self._downlink_cancel_active = False
                self._downlink_cancel_finished = False
                self._round_result_consumed = False
                self._write_state('publishing_model')

            try:
                try:
                    write_current_round(self.work_dir, 'server', round_id)
                except Exception as exc:
                    self._fail_round(
                        'state_persistence_failed', '当前轮次指针持久化失败')
                    raise self._failure from exc
                size_bytes, digest = archive_open_file(
                    source, source_stat, model_target)
                manifest = {
                    'schema_version': 1,
                    'artifact_type': 'model',
                    'round_id': round_id,
                    'size_bytes': size_bytes,
                    'sha256': digest,
                    'participant_node_ids': list(self.participant_node_ids),
                }
                write_json_atomic(manifest_path, manifest)
                self.transport.install_round(
                    round_id=round_id,
                    participant_node_ids=self.participant_node_ids,
                    round_dir=round_dir,
                    max_update_size_bytes=self.max_update_size_bytes,
                    failure_callback=self.report_update_failure,
                )
                operation = self.transport.start_downlink(
                    round_id, model_target, manifest_path)
                with self._condition:
                    self._downlink_operation = operation
                    failure = self._failure
                if failure is not None:
                    self._cancel_downlink(operation)
                try:
                    self.transport.wait_downlink(operation)
                except FLRuntimeError as exc:
                    self._record_downlink_natural_result({
                        'error_code': exc.error_code,
                        'error_message': exc.error_message,
                    })
                    raise
                except Exception as exc:
                    self._record_downlink_natural_result({
                        'error_code': type(exc).__name__,
                        'error_message': str(exc),
                    })
                    raise
                else:
                    with self._condition:
                        while self._downlink_cancel_active:
                            self._condition.wait()
                        cancelled = (
                            self._downlink_diagnostics.get('cancel_result') ==
                            'cancelled')
                    if not cancelled:
                        self._record_downlink_natural_result('succeeded')
                finally:
                    with self._condition:
                        self._downlink_operation = None
            except FLRuntimeError as exc:
                if self._failure is None:
                    self._fail_round(exc.error_code, exc.error_message)
                with self._condition:
                    self._round_result_consumed = True
                raise self._fatal_error or self._failure or exc
            except Exception as exc:
                self._fail_round('transport_failed', 'UFTP 下行失败')
                with self._condition:
                    self._round_result_consumed = True
                raise self._fatal_error or self._failure from exc

            with self._condition:
                if self._fatal_error is not None:
                    self._round_result_consumed = True
                    raise self._fatal_error
                if self._failure is not None:
                    self._round_result_consumed = True
                    raise self._failure
                self._downlink_completed = True
                self._write_state('waiting_for_updates')
                self._condition.notify_all()
            self._complete_round_if_ready(round_id, round_dir)
            return None
        finally:
            source.close()

    def abort(self, reason='aborted'):
        with self._condition:
            if self._fatal_error is None:
                self._fatal_error = FLRuntimeError('aborted', f'协同作业被主动中止: {reason}')
            self._condition.notify_all()
        operation = self._downlink_operation if self._publish_active else None
        if operation is not None:
            try:
                self._cancel_downlink(operation)
            except Exception:
                pass

    def wait_for_updates(self, min_updates=None, timeout=None):
        self._require_ready()
        with self._condition:
            if self._wait_for_updates_active:
                raise FLRuntimeError('operation_in_progress', '已有 update 等待正在进行')
            if self._round_id is None:
                raise FLRuntimeError('no_active_round', '没有活动轮次')
            self._wait_for_updates_active = True
            round_id = self._round_id
            round_dir = self._round_dir

        try:
            if self._state == 'succeeded':
                result = self._rebuild_terminal_updates(round_id, round_dir)
            else:
                result = self._wait_for_complete_updates(
                    round_id, round_dir, min_updates=min_updates, timeout=timeout)
            with self._condition:
                self._round_result_consumed = True
            return result
        except FLRuntimeError:
            with self._condition:
                self._round_result_consumed = True
            raise
        finally:
            with self._condition:
                self._wait_for_updates_active = False

    def _wait_for_complete_updates(self, round_id, round_dir, min_updates=None, timeout=None):
        deadline = (time.monotonic() + timeout) if timeout is not None else None
        min_required = min_updates if min_updates is not None else len(self.participant_node_ids)
        while True:
            with self._condition:
                if self._fatal_error is not None:
                    raise self._fatal_error
                if self._failure is not None:
                    raise self._failure
            update_paths = self._complete_round_if_ready(
                round_id, round_dir, min_updates=min_required)
            if update_paths is not None:
                return MappingProxyType(update_paths)

            if deadline is not None and time.monotonic() >= deadline:
                self._fail_round(
                    'round_timeout',
                    '轮次等待 update 超时，未达到最小配额: 期望 %d' % min_required)
                with self._condition:
                    raise self._failure

            self.transport.wait_for_update(0.1)

    def _rebuild_terminal_updates(self, round_id, round_dir):
        update_paths = {}
        state_path = os.path.join(round_dir, 'state.json')
        if not os.path.isfile(state_path):
            raise FLRuntimeError('round_artifacts_removed', '轮次状态文件缺失', round_id=round_id)
        state = read_json(state_path)
        committed_node_ids = state.get('committed_update_node_ids')
        if not isinstance(committed_node_ids, list) or not committed_node_ids:
            raise FLRuntimeError('round_state_corrupted', '轮次状态提交节点集无效', round_id=round_id)

        for node_id in committed_node_ids:
            update_dir = os.path.join(round_dir, 'updates', str(node_id))
            manifest_path = os.path.join(update_dir, 'update.manifest.json')
            update_path = os.path.abspath(os.path.join(update_dir, 'update.bin'))
            if not os.path.isfile(manifest_path) or not os.path.isfile(update_path):
                raise FLRuntimeError(
                    'round_artifacts_removed', '轮次托管交付物已被移除',
                    round_id=round_id)
            try:
                manifest = read_json(manifest_path)
                self._validate_update_manifest(manifest, round_id, node_id)
                validate_artifact(
                    update_path, manifest['size_bytes'], manifest['sha256'],
                    self.max_update_size_bytes)
            except (FLRuntimeError, OSError) as exc:
                raise FLRuntimeError(
                    'round_artifacts_corrupted', '轮次托管交付物已损坏',
                    round_id=round_id, node_id=node_id) from exc
            update_paths[node_id] = update_path
        return MappingProxyType(update_paths)

    def _complete_round_if_ready(self, round_id, round_dir, min_updates=None):
        with self._condition:
            if not self._downlink_completed:
                return None
        min_required = min_updates if min_updates is not None else len(self.participant_node_ids)
        available_updates = {}
        for node_id in self.participant_node_ids:
            update_dir = os.path.join(round_dir, 'updates', str(node_id))
            manifest_path = os.path.join(update_dir, 'update.manifest.json')
            bin_path = os.path.join(update_dir, 'update.bin')
            if os.path.isfile(manifest_path) and os.path.isfile(bin_path):
                available_updates[node_id] = os.path.abspath(bin_path)

        if len(available_updates) < min_required:
            return None

        try:
            for node_id, update_path in available_updates.items():
                manifest_path = os.path.join(
                    round_dir, 'updates', str(node_id), 'update.manifest.json')
                manifest = read_json(manifest_path)
                self._validate_update_manifest(manifest, round_id, node_id)
                validate_artifact(
                    update_path, manifest['size_bytes'], manifest['sha256'],
                    self.max_update_size_bytes)
        except FLRuntimeError as exc:
            self._fail_round(exc.error_code, exc.error_message)
            raise
        with self._condition:
            if self._failure is not None:
                raise self._failure
            node_ids = list(self.participant_node_ids)
            committed_nodes = sorted(available_updates.keys())
            self._write_state(
                'succeeded',
                participant_node_ids=node_ids,
                committed_update_node_ids=committed_nodes,
            )
        return available_updates

    def report_update_failure(self, round_id, node_id, error_code, error_message):
        persistence_error = None
        with self._condition:
            if (round_id != self._round_id or
                    node_id not in self.participant_node_ids or
                    self._state in ('succeeded', 'failed') or
                    self._failure is not None):
                return
            self._failure = FLRuntimeError(
                error_code, error_message, round_id=round_id, node_id=node_id)
            try:
                self._write_state(
                    'failed', error_code=error_code, error_message=error_message,
                    node_id=node_id)
            except Exception as exc:
                persistence_error = exc
            self._condition.notify_all()
            operation = self._downlink_operation if self._publish_active else None
        if operation is not None:
            self._cancel_downlink(operation)
        if persistence_error is not None:
            raise persistence_error

    def _cancel_downlink(self, operation):
        with self._condition:
            while self._downlink_cancel_active:
                self._condition.wait()
            if self._downlink_cancel_finished:
                return
            self._downlink_cancel_active = True
        try:
            result = self.transport.cancel_downlink(operation)
        except Exception as exc:
            diagnostics = {
                'cancel_error': {
                    'exception_type': type(exc).__name__,
                    'message': str(exc),
                },
            }
        else:
            diagnostics = {'cancel_result': result}
        with self._condition:
            self._downlink_diagnostics.update(diagnostics)
            self._downlink_cancel_active = False
            self._downlink_cancel_finished = True
            self._persist_downlink_diagnostics()
            self._condition.notify_all()

    def _record_downlink_natural_result(self, result):
        with self._condition:
            self._downlink_diagnostics['natural_result'] = result
            self._persist_downlink_diagnostics()

    def _persist_downlink_diagnostics(self):
        if self._state != 'failed' or self._failure is None:
            return
        value = {
            'schema_version': 1,
            'round_id': self._round_id,
            'role': 'server',
            'state': 'failed',
            'error_code': self._failure.error_code,
            'error_message': self._failure.error_message,
            'downlink_diagnostics': dict(self._downlink_diagnostics),
        }
        if self._failure.node_id is not None:
            value['node_id'] = self._failure.node_id
        try:
            write_json_atomic(
                os.path.join(self._round_dir, 'round-state.json'), value)
        except Exception as exc:
            self._downlink_diagnostics_persistence_error = exc

    def _validate_update_manifest(self, manifest, round_id, node_id):
        _validate_exact_fields(manifest, (
            'schema_version', 'artifact_type', 'round_id', 'node_id',
            'size_bytes', 'sha256'))
        if (type(manifest['schema_version']) is not int or
                manifest['schema_version'] != 1 or
                manifest['artifact_type'] != 'update' or
                _parse_round_id(manifest['round_id']) != round_id or
                type(manifest['node_id']) is not int or
                manifest['node_id'] != node_id):
            raise FLRuntimeError('invalid_manifest', 'update manifest 身份无效')
        if type(manifest['size_bytes']) is not int or manifest['size_bytes'] < 0:
            raise FLRuntimeError('invalid_manifest', 'update manifest 大小无效')
        if manifest['size_bytes'] > self.max_update_size_bytes:
            raise FLRuntimeError('artifact_too_large', 'update 超过大小限制')
        _validate_sha256(manifest['sha256'])

    def _require_ready(self):
        if self._fatal_error is not None:
            raise self._fatal_error
        if not self.transport.ready:
            raise FLRuntimeError('transport_not_ready', 'Transport 尚未 ready')

    def _write_state(self, state, **extra):
        value = {
            'schema_version': 1,
            'round_id': self._round_id,
            'role': 'server',
            'state': state,
        }
        value.update(extra)
        try:
            write_json_atomic(os.path.join(self._round_dir, 'round-state.json'), value)
        except Exception as exc:
            self._fatal_error = FLRuntimeError(
                'state_persistence_failed', 'server 轮次状态持久化失败',
                round_id=self._round_id)
            raise self._fatal_error from exc
        self._state = state

    def _fail_round(self, error_code, error_message):
        with self._condition:
            if (self._round_dir is None or self._failure is not None or
                    self._state == 'succeeded'):
                return
            self._failure = FLRuntimeError(
                error_code, error_message, round_id=self._round_id)
            extra = {
                'error_code': error_code,
                'error_message': error_message,
            }
            if self._downlink_diagnostics:
                extra['downlink_diagnostics'] = dict(
                    self._downlink_diagnostics)
            self._write_state('failed', **extra)
            self._condition.notify_all()


class ClientRuntime(object):
    def __init__(self, work_dir, node_id, max_update_size_bytes, transport):
        self.work_dir = os.path.abspath(work_dir)
        if not isinstance(node_id, int) or isinstance(node_id, bool) or node_id <= 0:
            raise FLRuntimeError('invalid_configuration', '本机节点标识无效')
        self.node_id = node_id
        _validate_max_update_size(max_update_size_bytes)
        self.max_update_size_bytes = max_update_size_bytes
        self.transport = transport
        self._owner = WorkDirLock(self.work_dir)
        try:
            recovered_state = recover_round_states(self.work_dir, 'client')
        except Exception:
            self._owner.close()
            raise
        self._condition = threading.Condition()
        self._fatal_error = None
        self._round_id = None
        self._round_dir = None
        self._state = None
        self._failure = None
        self._round_result_consumed = True
        self._wait_for_model_active = False
        self._submit_update_active = False
        if recovered_state is not None:
            self._restore_terminal_state(recovered_state)

    def close(self):
        self._owner.close()

    def abort(self, reason='aborted'):
        with self._condition:
            if self._fatal_error is None:
                self._fatal_error = FLRuntimeError('aborted', f'协同作业被主动中止: {reason}')
            self._condition.notify_all()

    @property
    def round_id(self):
        with self._condition:
            return self._round_id

    def _restore_terminal_state(self, state):
        round_id = state['round_id']
        if state['state'] == 'failed':
            self._failure = FLRuntimeError(
                state['error_code'], state['error_message'],
                round_id=round_id, node_id=state.get('node_id'))
        self._round_id = round_id
        self._round_dir = os.path.join(self.work_dir, 'rounds', round_id)
        self._state = state['state']
        self._round_result_consumed = False

    def wait_for_model(self):
        self._require_ready()
        with self._condition:
            if self._wait_for_model_active:
                raise FLRuntimeError('operation_in_progress', '已有模型等待正在进行')
            if self._round_id is not None:
                if self._state in ('succeeded', 'failed'):
                    if not self._round_result_consumed:
                        raise FLRuntimeError('round_result_pending', '轮次结果尚未消费')
                else:
                    raise FLRuntimeError('round_in_progress', '已有活动轮次')
            self._wait_for_model_active = True
        try:
            return self._wait_for_model()
        finally:
            with self._condition:
                self._wait_for_model_active = False

    def _wait_for_model(self):
        while True:
            with self._condition:
                if self._fatal_error is not None:
                    raise self._fatal_error
            candidate_dir = self.transport.wait_for_model_candidate()
            manifest = None
            try:
                manifest = read_json(os.path.join(candidate_dir, 'model.manifest.json'))
                self._validate_model_manifest(manifest)
            except FLRuntimeError as exc:
                round_id = self._candidate_round_id(manifest)
                if round_id is not None:
                    self._fail_model_delivery(round_id, exc)
                self._quarantine_candidate(candidate_dir, exc.error_code, exc.error_message)
                raise

            round_id = manifest['round_id']
            if self.node_id not in manifest['participant_node_ids']:
                self._quarantine_candidate(
                    candidate_dir, 'model_not_for_this_node', '模型不属于本节点')
                continue

            existing_manifest = self._read_existing_model_manifest(round_id)
            if existing_manifest is not None:
                if self._model_delivery_matches(
                        candidate_dir, manifest, existing_manifest, round_id):
                    self._quarantine_candidate(
                        candidate_dir, 'duplicate_model_ignored',
                        '重复模型交付已忽略')
                    continue
                self._quarantine_candidate(
                    candidate_dir, 'round_id_content_conflict',
                    '相同轮次标识对应不同模型内容')
                raise FLRuntimeError(
                    'round_id_content_conflict', '相同轮次标识对应不同模型内容',
                    round_id=round_id, node_id=self.node_id)

            source_model = os.path.join(candidate_dir, 'model.bin')
            try:
                validate_artifact(
                    source_model, manifest['size_bytes'], manifest['sha256'])
                round_dir = os.path.join(self.work_dir, 'rounds', round_id)
                model_path = os.path.abspath(os.path.join(round_dir, 'model.bin'))
                size_bytes, digest = archive_file(source_model, model_path)
                if size_bytes != manifest['size_bytes'] or digest != manifest['sha256']:
                    raise FLRuntimeError(
                        'artifact_integrity_failed', '模型归档校验失败')
                write_json_atomic(
                    os.path.join(round_dir, 'model.manifest.json'), manifest)
            except FLRuntimeError as exc:
                self._fail_model_delivery(round_id, exc)
                self._quarantine_candidate(
                    candidate_dir, exc.error_code, exc.error_message)
                raise FLRuntimeError(
                    exc.error_code, exc.error_message,
                    round_id=round_id, node_id=self.node_id) from exc

            self._round_id = round_id
            self._round_dir = round_dir
            self._failure = None
            self._round_result_consumed = True
            self._write_state('model_received')
            try:
                write_current_round(self.work_dir, 'client', round_id)
            except Exception as exc:
                self._write_failed_state(
                    'state_persistence_failed', '当前轮次指针持久化失败')
                raise FLRuntimeError(
                    'state_persistence_failed', '当前轮次指针持久化失败',
                    round_id=round_id, node_id=self.node_id) from exc
            return model_path

    def _candidate_round_id(self, manifest):
        if not isinstance(manifest, dict):
            return None
        try:
            return _parse_round_id(manifest.get('round_id'))
        except FLRuntimeError:
            return None

    def _read_existing_model_manifest(self, round_id):
        manifest_path = os.path.join(
            self.work_dir, 'rounds', round_id, 'model.manifest.json')
        if not os.path.isfile(manifest_path):
            return None
        try:
            manifest = read_json(manifest_path)
            self._validate_model_manifest(manifest)
            return manifest
        except FLRuntimeError as exc:
            raise FLRuntimeError(
                'round_artifacts_corrupted', '既有模型托管交付物已损坏',
                round_id=round_id, node_id=self.node_id) from exc

    def _model_delivery_matches(
            self, candidate_dir, manifest, existing_manifest, round_id):
        if manifest != existing_manifest:
            return False
        try:
            validate_artifact(
                os.path.join(candidate_dir, 'model.bin'),
                manifest['size_bytes'], manifest['sha256'])
            validate_artifact(
                os.path.join(self.work_dir, 'rounds', round_id, 'model.bin'),
                existing_manifest['size_bytes'], existing_manifest['sha256'])
        except FLRuntimeError:
            return False
        return True

    def _fail_model_delivery(self, round_id, error):
        round_dir = os.path.join(self.work_dir, 'rounds', round_id)
        state_path = os.path.join(round_dir, 'round-state.json')
        if os.path.isfile(state_path):
            try:
                state = read_json(state_path)
            except FLRuntimeError:
                state = None
            if isinstance(state, dict) and state.get('state') in ('succeeded', 'failed'):
                return
        os.makedirs(round_dir, exist_ok=True)
        self._round_id = round_id
        self._round_dir = round_dir
        self._failure = FLRuntimeError(
            error.error_code, error.error_message,
            round_id=round_id, node_id=self.node_id)
        self._round_result_consumed = True
        self._write_failed_state(error.error_code, error.error_message)
        write_current_round(self.work_dir, 'client', round_id)

    def _quarantine_candidate(self, candidate_dir, error_code, error_message):
        rejected_root = os.path.join(self.work_dir, 'rejected-models')
        os.makedirs(rejected_root, exist_ok=True)
        while True:
            rejected_dir = os.path.join(rejected_root, str(uuid.uuid4()))
            try:
                os.makedirs(rejected_dir)
                break
            except FileExistsError:
                continue
        try:
            shutil.move(candidate_dir, os.path.join(rejected_dir, 'delivery'))
        except (OSError, shutil.Error) as exc:
            raise FLRuntimeError(
                'model_quarantine_failed', '模型候选隔离失败',
                node_id=self.node_id) from exc
        write_json_atomic(os.path.join(rejected_dir, 'rejection.json'), {
            'schema_version': 1,
            'error_code': error_code,
            'error_message': error_message,
        })

    def submit_update(self, update_path):
        self._require_ready()
        with self._condition:
            if self._submit_update_active:
                raise FLRuntimeError('operation_in_progress', '已有 update 提交正在进行')
            if self._round_id is None:
                raise FLRuntimeError('no_active_round', '没有活动轮次')
            if self._state == 'succeeded':
                if not self._round_result_consumed:
                    self._round_result_consumed = True
                    return None
                raise FLRuntimeError('round_already_succeeded', '轮次已成功')
            if self._state == 'failed':
                if not self._round_result_consumed:
                    self._round_result_consumed = True
                    raise self._failure
                raise FLRuntimeError('round_already_failed', '轮次已失败')
            if self._state != 'model_received':
                raise FLRuntimeError('round_in_progress', '轮次正在提交 update')
            self._submit_update_active = True
        source = None
        try:
            source, source_stat = preflight_artifact(
                update_path, self.max_update_size_bytes)
            self._write_state('submitting_update')
            return self._submit_update(source, source_stat)
        except FLRuntimeError as exc:
            if self._state == 'submitting_update':
                self._failure = FLRuntimeError(
                    exc.error_code, exc.error_message,
                    round_id=self._round_id, node_id=self.node_id)
                self._write_failed_state(exc.error_code, exc.error_message)
            raise
        except Exception as exc:
            error = FLRuntimeError(
                'update_submit_failed', 'update 提交失败',
                round_id=self._round_id, node_id=self.node_id)
            self._failure = error
            self._write_failed_state(error.error_code, error.error_message)
            raise error from exc
        finally:
            if source is not None:
                source.close()
            with self._condition:
                self._submit_update_active = False

    def _submit_update(self, source, source_stat):
        managed_update = os.path.join(self._round_dir, 'update.bin')
        size_bytes, digest = archive_open_file(
            source, source_stat, managed_update, self.max_update_size_bytes)
        manifest = {
            'schema_version': 1,
            'artifact_type': 'update',
            'round_id': self._round_id,
            'node_id': self.node_id,
            'size_bytes': size_bytes,
            'sha256': digest,
        }
        write_json_atomic(os.path.join(self._round_dir, 'update.manifest.json'), manifest)
        self.transport.submit_update(
            self._round_id, self.node_id, managed_update, size_bytes, digest)
        self._write_state('succeeded')
        return None

    def _validate_model_manifest(self, manifest):
        _validate_exact_fields(manifest, (
            'schema_version', 'artifact_type', 'round_id', 'size_bytes',
            'sha256', 'participant_node_ids'))
        if (type(manifest['schema_version']) is not int or
                manifest['schema_version'] != 1 or
                manifest['artifact_type'] != 'model'):
            raise FLRuntimeError('invalid_manifest', '模型 manifest 身份无效')
        _parse_round_id(manifest['round_id'])
        participant_node_ids = manifest['participant_node_ids']
        if (not isinstance(participant_node_ids, list) or
                not participant_node_ids or
                any(type(node_id) is not int or node_id <= 0
                    for node_id in participant_node_ids) or
                participant_node_ids != sorted(set(participant_node_ids))):
            raise FLRuntimeError('invalid_manifest', '模型 manifest 参与集合无效')
        if type(manifest['size_bytes']) is not int or manifest['size_bytes'] < 0:
            raise FLRuntimeError('invalid_manifest', '模型 manifest 大小无效')
        _validate_sha256(manifest['sha256'])

    def _require_ready(self):
        if self._fatal_error is not None:
            raise self._fatal_error
        if not self.transport.ready:
            raise FLRuntimeError('transport_not_ready', 'Transport 尚未 ready')

    def _write_state(self, state, **extra):
        value = {
            'schema_version': 1,
            'round_id': self._round_id,
            'role': 'client',
            'state': state,
        }
        value.update(extra)
        try:
            write_json_atomic(os.path.join(self._round_dir, 'round-state.json'), value)
        except Exception as exc:
            self._fatal_error = FLRuntimeError(
                'state_persistence_failed', 'client 轮次状态持久化失败',
                round_id=self._round_id, node_id=self.node_id)
            raise self._fatal_error from exc
        self._state = state

    def _write_failed_state(self, error_code, error_message):
        self._write_state(
            'failed', error_code=error_code, error_message=error_message,
            node_id=self.node_id)
