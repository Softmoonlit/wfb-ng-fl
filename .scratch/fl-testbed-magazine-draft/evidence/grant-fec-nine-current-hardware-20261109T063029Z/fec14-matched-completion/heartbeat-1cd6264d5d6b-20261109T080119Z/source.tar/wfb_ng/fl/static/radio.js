(() => {
  'use strict';
  const byId = id => document.getElementById(id);
  const fields = ['channel', 'bandwidth_mhz', 'radio_txpower_dbm', 'downlink_mcs', 'uplink_mcs', 'uftp_rate_kbps'];
  const states = {idle:'待命', starting:'启动中', preparing:'准备中', running:'运行中', aborting:'中止 / 恢复中', radio_error:'射频错误 RADIO_ERROR', unavailable:'不可用'};
  const recoveries = {not_required:'无需恢复', recovering:'正在恢复待命', ready:'已恢复待命', blocked:'恢复受阻'};
  const results = {none:'未执行', running:'执行中', succeeded:'成功', failed:'失败', aborted:'已急停'};
  let snapshot = null, rateBounds = {}, initialized = false, connected = false;
  let confirmation = null, busy = false, stopping = false, fetching = false;
  let readVersion = 0, editVersion = 0, lastRefresh = 0;
  let rateCombination = '';
  const combination = () => `${byId('bandwidth_mhz').value}/${byId('downlink_mcs').value}`;

  function describe(config) {
    return config ? `信道 ${config.channel} · ${config.bandwidth_mhz} MHz · 功率索引 ${config.radio_txpower_dbm} · 下行 MCS ${config.downlink_mcs} · 上行 MCS ${config.uplink_mcs} · UFTP ${config.uftp_rate_kbps} kbps` : '射频配置未确认';
  }
  function showError(id, message) {
    byId(id).textContent = message;
    byId(id).hidden = false;
  }
  async function request(path, body) {
    const options = body === undefined ? {cache:'no-store'} : {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)};
    const response = await fetch(path, options);
    const data = await response.json();
    if (!response.ok) throw new Error(`${data.error.code}: ${data.error.message}`);
    return data;
  }
  function clearConfirmation(message = '请校验配置，再明确点击应用。') {
    confirmation = null;
    byId('validated-config').textContent = message;
    byId('confirmation-status').textContent = '';
  }
  function activeJob() {
    if (!snapshot) return null;
    return snapshot.current_job || (snapshot.job && snapshot.job.execution_result === 'running' ? snapshot.job : null);
  }
  function blockers() {
    if (!connected || !snapshot) return ['状态尚未连接或可能已过时，请刷新状态。'];
    const reasons = [];
    if (snapshot.server.state !== 'idle') reasons.push('Server 尚未待命，禁止应用射频。');
    if (activeJob()) reasons.push('作业正在运行，禁止应用射频。');
    const recovery = snapshot.recovery_state || (snapshot.job && snapshot.job.recovery_state);
    if (recovery && !['ready', 'not_required'].includes(recovery)) reasons.push('资源尚未恢复待命，禁止应用射频。');
    for (const blocker of snapshot.server.start_blockers || []) {
      if (blocker.code !== 'RADIO_NOT_READY') reasons.push(`${blocker.message} (${blocker.code})`);
    }
    return reasons;
  }
  function outside(config, bounds) {
    return bounds && (config.uftp_rate_kbps < bounds.min_rate_kbps || config.uftp_rate_kbps > bounds.max_rate_kbps);
  }
  function selectedBounds() {
    const bandwidth = rateBounds[byId('bandwidth_mhz').value];
    return bandwidth && bandwidth[byId('downlink_mcs').value];
  }
  function render() {
    if (confirmation && Date.now() >= confirmation.expiresAt) clearConfirmation('确认已过期，请重新校验配置。');
    const bounds = selectedBounds();
    byId('rate-range').textContent = bounds ? `安全范围 ${bounds.min_rate_kbps}–${bounds.max_rate_kbps} kbps · 推荐 ${bounds.default_rate_kbps} kbps` : `${byId('bandwidth_mhz').value} MHz / MCS ${byId('downlink_mcs').value} 的实测速率范围不可用；缺少标定表时后端拒绝普通配置。`;
    const localRisk = outside({uftp_rate_kbps:Number(byId('uftp_rate_kbps').value)}, bounds);
    byId('rate-warning').textContent = localRisk ? 'UFTP 速率超出安全范围，后端将拒绝配置；请调整速率。' : '';
    byId('rate-warning').hidden = !localRisk;
    const reasons = blockers();
    byId('apply-blockers').textContent = reasons.length ? reasons.join(' · ') : '集群空闲；应用仍由 Server 校验最新状态并协调节点。';
    byId('validate').disabled = busy || !!reasons.length;
    byId('apply').disabled = busy || !!reasons.length || !confirmation;
    byId('emergency-stop').disabled = stopping || !activeJob();
    if (confirmation) byId('confirmation-status').textContent = `已校验 · 确认剩余 ${Math.max(0, Math.ceil((confirmation.expiresAt - Date.now()) / 1000))} 秒`;
  }
  function renderSnapshot(state) {
    if (snapshot && snapshot.instance_id !== state.instance_id) {
      byId('instance-notice').hidden = false;
      byId('instance-notice').textContent = '服务已重启，前次作业状态不可用；请重新校验配置。';
    }
    if (confirmation && (confirmation.instance_id !== state.instance_id || confirmation.state_version !== state.state_version)) {
      clearConfirmation('Server 状态已变化，请重新校验配置。');
    }
    snapshot = state;
    const job = state.job;
    byId('server-state').textContent = states[state.server.state] || state.server.state;
    byId('resources').textContent = `TUN ${state.server.tun.is_active ? '就绪' : '未就绪'} · 链路 ${state.server.link_process.running ? '运行' : '未运行'}`;
    byId('job-result').textContent = `${job ? job.job_id + ' · ' : ''}${results[job ? job.execution_result : 'none'] || '未知'}`;
    const recovery = state.recovery_state || (job && job.recovery_state) || 'not_required';
    byId('recovery-state').textContent = recoveries[recovery] || recovery;
    byId('job-error').textContent = job ? [job.error, job.recovery_error, job.reason].filter(Boolean).join(' · ') : '';
    byId('snapshot-time').textContent = `状态版本 ${state.state_version} · 更新于 ${state.generated_at}`;
    byId('nodes').replaceChildren(...state.nodes.map(node => {
      const row = document.createElement('li');
      row.textContent = `节点 ${node.node_id} · ${node.online ? '在线' : '离线'} · ${node.state} · ${node.readiness}${node.error_code ? ' · ' + node.error_code : ''}`;
      return row;
    }));
    if (byId('hud-server-state')) {
      const serverStateText = states[state.server.state] || state.server.state;
      byId('hud-server-state').textContent = serverStateText;
      byId('hud-server-state').className = `badge ${state.server.state === 'idle' ? 'badge-green' : state.server.state === 'running' ? 'badge-blue' : state.server.state === 'starting' || state.server.state === 'preparing' ? 'badge-yellow' : 'badge-red'}`;
    }
    if (byId('hud-radio')) {
      const radioConfig = state.server.radio;
      byId('hud-radio').textContent = radioConfig ? `CH${radioConfig.channel} · ${radioConfig.bandwidth_mhz}MHz · 索引${radioConfig.radio_txpower_dbm} · MCS${radioConfig.downlink_mcs}` : '未确认';
    }
    if (byId('hud-job')) {
      if (state.current_job && state.server.state === 'running') {
        byId('hud-job').textContent = `轮次 ${state.current_job.current_round || 0}/${state.current_job.rounds} · 运行中`;
      } else {
        const recent = state.recent_job || state.job;
        if (recent && recent.execution_result === 'aborted') {
          byId('hud-job').textContent = recent.recovery_state === 'ready' ? '作业已急停 · 链路已就绪' : '作业已急停 · 恢复待命中';
        } else if (recent && recent.execution_result === 'failed') {
          byId('hud-job').textContent = recent.recovery_state === 'ready' ? '作业失败 · 链路已就绪' : '作业失败 · 恢复待命中';
        } else if (recent && recent.execution_result === 'succeeded') {
          byId('hud-job').textContent = '作业成功 · 已完成';
        } else {
          byId('hud-job').textContent = '空闲待命';
        }
      }
    }
  }
  async function refresh() {
    if (busy) return;
    const version = ++readVersion;
    fetching = true;
    lastRefresh = Date.now();
    try {
      const body = await request('/api/v1/radio/config');
      if (version !== readVersion) return;
      rateBounds = body.rate_bounds;
      renderSnapshot(body.snapshot);
      byId('current-config').textContent = describe(body.config);
      if (!initialized) {
        if (body.config && editVersion === 0) fields.forEach(field => {byId(field).value = String(body.config[field]);});
        rateCombination = combination();
        initialized = true;
      }
      connected = true;
      byId('connection-error').hidden = true;
    } catch (error) {
      if (version !== readVersion) return;
      connected = false;
      clearConfirmation('连接中断，确认已清除；重连后请重新校验。');
      showError('connection-error', `状态可能已过时。${error.message}。请重试刷新状态。`);
    } finally {
      if (version === readVersion) fetching = false;
      render();
    }
  }
  function readConfig() {
    const config = {};
    fields.forEach(field => {
      const value = byId(field).value.trim();
      if (!/^\d+$/.test(value) || !Number.isSafeInteger(Number(value))) throw new Error('请完整填写六项整数参数。');
      config[field] = Number(value);
    });
    if (![149,153,157,165].includes(config.channel)) throw new Error('仅允许信道 149、153、157、165；禁止 Channel 161。');
    if (![20,40].includes(config.bandwidth_mhz)) throw new Error('带宽必须为 20 或 40 MHz。');
    if (config.radio_txpower_dbm < 1 || config.radio_txpower_dbm > 63) throw new Error('驱动固定功率索引必须为 1–63。');
    if (![3,4,5,6].includes(config.downlink_mcs) || ![3,4,5,6].includes(config.uplink_mcs)) throw new Error('上下行 MCS 必须为 3–6。');
    if (config.uftp_rate_kbps <= 0) throw new Error('UFTP 速率必须为正整数。');
    return config;
  }
  byId('radio-form').addEventListener('submit', async event => {
    event.preventDefault();
    if (busy || blockers().length) return;
    clearConfirmation();
    byId('action-error').hidden = true;
    let config;
    try {config = readConfig();} catch (error) {showError('action-error', error.message);render();return;}
    const revision = editVersion;
    const instance = snapshot.instance_id, stateVersion = snapshot.state_version;
    busy = true;
    ++readVersion;
    fetching = false;
    byId('action-status').textContent = '正在校验配置…';
    render();
    try {
      const body = await request('/api/v1/radio/config/validate', {config});
      if (revision !== editVersion) {byId('action-status').textContent = '输入已变化，请重新校验。';return;}
      if (body.confirmation.instance_id !== instance || body.confirmation.state_version !== stateVersion) {
        throw new Error('Server 状态已变化，请刷新后重新校验。');
      }
      confirmation = {...body.confirmation, expiresAt:Date.now() + body.confirmation.expires_in_seconds * 1000};
      byId('validated-config').textContent = describe(body.config);
      byId('action-status').textContent = '校验完成。请核对规范配置，再明确点击应用。';
    } catch (error) {
      clearConfirmation();
      byId('action-status').textContent = '';
      showError('action-error', `校验失败。${error.message}`);
    } finally {busy = false;render();}
  });
  byId('apply').addEventListener('click', async () => {
    render();
    if (byId('apply').disabled) return;
    const token = confirmation.token;
    clearConfirmation('应用请求已发出；再次应用需要重新校验。');
    busy = true;
    ++readVersion;
    fetching = false;
    byId('action-error').hidden = true;
    byId('action-status').textContent = '正在应用射频，请等待事务结果…';
    render();
    try {
      const result = await request('/api/v1/radio/config/apply', {confirmation_token:token, confirm_risk:false});
      byId('action-status').textContent = `射频事务结果：${result.status || '已返回'}${result.error_message ? ' · ' + result.error_message : ''}`;
      byId('transaction-result').textContent = JSON.stringify(result, null, 2);
      busy = false;
      await refresh();
    } catch (error) {
      byId('action-status').textContent = '未确认应用结果；请刷新状态，重新校验后再操作。';
      showError('action-error', `应用失败。${error.message}`);
      connected = false;
    } finally {busy = false;render();}
  });
  byId('emergency-stop').addEventListener('click', async () => {
    const job = activeJob();
    if (stopping || !job) return;
    stopping = true;
    clearConfirmation('急停已请求，请等待资源恢复并重新校验。');
    byId('stop-error').hidden = true;
    byId('stop-status').textContent = '正在发送急停请求…';
    render();
    try {
      await request(`/api/v1/jobs/${encodeURIComponent(job.job_id)}/abort`, {reason:'operator_abort'});
      byId('stop-status').textContent = '急停请求已受理；资源是否恢复以最新状态为准。';
      await refresh();
    } catch (error) {
      byId('stop-status').textContent = '尚未确认急停受理，可重试。';
      showError('stop-error', `急停请求失败。${error.message}`);
    } finally {stopping = false;render();}
  });
  fields.forEach(field => {
    // input 与 change 可能先后到达，只在组合实际改变时采用推荐值。
    const changed = () => {
      if (rateCombination !== combination() && ['bandwidth_mhz', 'downlink_mcs'].includes(field)) {
        const bounds = selectedBounds();
        byId('uftp_rate_kbps').value = bounds ? String(bounds.default_rate_kbps) : '';
      }
      rateCombination = combination();
      ++editVersion;
      clearConfirmation('输入已变化，请重新校验配置。');
      render();
    };
    byId(field).addEventListener('input', changed);
    byId(field).addEventListener('change', changed);
  });
  byId('refresh').addEventListener('click', refresh);
  render();
  refresh();
  setInterval(() => {
    render();
    if (!fetching && !busy && Date.now() - lastRefresh >= 3000) refresh();
  }, 1000);
})();
