// -*- C++ -*-
//
// Copyright (C) 2017 - 2024 Vasily Evseenko <svpcom@p2ptech.org>

/*
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; version 3.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License along
 *   with this program; if not, write to the Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <sys/resource.h>
#include <pcap.h>
#include <poll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <limits.h>
#include <sys/ioctl.h>
#include <linux/random.h>

#include "zfex.h"

extern "C"
{
#include "ieee80211_radiotap.h"
}

#include <string>
#include <memory>

#include "wifibroadcast.hpp"
#include "rx.hpp"
#include "control_envelope.hpp"

using namespace std;

const char *ready_decision_reason(ReadyDecision decision)
{
    switch (decision)
    {
    case ReadyDecision::ignore_invalid_source:
        return "invalid_source";
    case ReadyDecision::ignore_wrong_ingress_or_link_domain:
        return "wrong_ingress_or_link_domain";
    case ReadyDecision::ignore_unknown_client:
        return "unknown_client";
    case ReadyDecision::accept:
    default:
        return "accept";
    }
}

void log_ready_rejection(const ControlEnvelopeView &envelope,
                        ReadyDecision decision,
                        uint8_t local_node_id,
                        const char *ingress_label)
{
    if (decision == ReadyDecision::accept)
    {
        return;
    }

    WFB_ERR("READY_REJECT reason=%s source_node=%u ingress=%s server_node_id=%u target_node=%u control_type=%u\n",
            ready_decision_reason(decision),
            static_cast<unsigned>(envelope.source_node),
            ingress_label,
            static_cast<unsigned>(local_node_id),
            static_cast<unsigned>(envelope.target_node),
            static_cast<unsigned>(envelope.control_type));
}

void log_data_rejection(const char *reason,
                       uint8_t source_node,
                       uint64_t source_local_block_idx,
                       uint8_t local_node_id)
{
    WFB_ERR("DATA_REJECT reason=%s source_node=%u source_local_block_idx=0x%" PRIx64 " server_node_id=%u\n",
            reason,
            static_cast<unsigned>(source_node),
            source_local_block_idx,
            static_cast<unsigned>(local_node_id));
}

set<uint8_t> parse_known_client_node_ids(const string &value)
{
    if (value.empty())
    {
        throw runtime_error("known_client_node_ids cannot be empty");
    }

    set<uint8_t> node_ids;
    size_t start = 0;
    while (start <= value.size())
    {
        size_t end = value.find(',', start);
        string item = value.substr(start, end == string::npos ? string::npos : end - start);
        if (item.empty())
        {
            throw runtime_error("known_client_node_ids contains empty item");
        }

        char *tail = NULL;
        errno = 0;
        unsigned long parsed = strtoul(item.c_str(), &tail, 10);
        if (errno != 0 || tail == item.c_str() || *tail != '\0' || parsed == 0 || parsed > 255)
        {
            throw runtime_error(string_format("Invalid known_client_node_id: %s", item.c_str()));
        }

        if (!node_ids.insert(static_cast<uint8_t>(parsed)).second)
        {
            throw runtime_error(string_format("Duplicate known_client_node_id: %s", item.c_str()));
        }

        if (end == string::npos)
        {
            break;
        }
        start = end + 1;
    }

    return node_ids;
}


Receiver::Receiver(const char *wlan, int wlan_idx, uint32_t channel_id, BaseAggregator *agg, int rcv_buf_size) : wlan_idx(wlan_idx), agg(agg)
{
    char errbuf[PCAP_ERRBUF_SIZE];

    ppcap = pcap_create(wlan, errbuf);

    if (ppcap == NULL){
        throw runtime_error(string_format("Unable to open interface %s in pcap: %s", wlan, errbuf));
    }

    try
    {
        if (rcv_buf_size > 0 && pcap_set_buffer_size(ppcap, rcv_buf_size) != 0) throw runtime_error("set_buffer_size failed");
        if (pcap_set_snaplen(ppcap, MAX_PCAP_PACKET_SIZE) != 0) throw runtime_error("set_snaplen failed");
        if (pcap_set_promisc(ppcap, 1) != 0) throw runtime_error("set_promisc failed");
        if (pcap_set_timeout(ppcap, -1) != 0) throw runtime_error("set_timeout failed");
        if (pcap_set_immediate_mode(ppcap, 1) != 0) throw runtime_error(string_format("pcap_set_immediate_mode failed: %s", pcap_geterr(ppcap)));
        if (pcap_activate(ppcap) !=0) throw runtime_error(string_format("pcap_activate failed: %s", pcap_geterr(ppcap)));
        if (pcap_setnonblock(ppcap, 1, errbuf) != 0) throw runtime_error(string_format("set_nonblock failed: %s", errbuf));

        int link_encap = pcap_datalink(ppcap);
        struct bpf_program bpfprogram;
        string program;

        if (link_encap != DLT_IEEE802_11_RADIO) {
            throw runtime_error(string_format("unknown encapsulation on %s", wlan));
        }

        program = string_format("ether[0x0a:2]==0x5742 && ether[0x0c:4] == 0x%08x", channel_id);

        if (pcap_compile(ppcap, &bpfprogram, program.c_str(), 1, 0) == -1) {
            throw runtime_error(string_format("Unable to compile %s: %s", program.c_str(), pcap_geterr(ppcap)));
        }

        if (pcap_setfilter(ppcap, &bpfprogram) == -1) {
            throw runtime_error(string_format("Unable to set filter %s: %s", program.c_str(), pcap_geterr(ppcap)));
        }

        pcap_freecode(&bpfprogram);
        fd = pcap_get_selectable_fd(ppcap);
    }
    catch(...)
    {
        pcap_close(ppcap);
        throw;
    }
}


Receiver::~Receiver()
{
    close(fd);
    pcap_close(ppcap);
}


void Receiver::loop_iter(void)
{
    const uint64_t batch_started_us = get_time_us();
    uint32_t packet_count = 0;
    for(;;) // loop while incoming queue is not empty
    {
        struct pcap_pkthdr hdr;
        const uint8_t* pkt = pcap_next(ppcap, &hdr);

        if (pkt == NULL) {
            break;
        }
        packet_count += 1;

        int pktlen = hdr.caplen;
        // int pkt_rate = 0
        int ant_idx = 0;
        uint32_t freq = 0;
        uint8_t antenna[RX_ANT_MAX];
        int8_t rssi[RX_ANT_MAX];
        int8_t noise[RX_ANT_MAX];
        uint8_t flags = 0;
        bool self_injected = false;
        uint8_t mcs_index = 0;
        uint8_t bandwidth = 20;

        struct ieee80211_radiotap_iterator iterator;
        int ret = ieee80211_radiotap_iterator_init(&iterator, (ieee80211_radiotap_header*)pkt, pktlen, NULL);

        // Fill all antenna slots with 0xff (unused)
        memset(antenna, 0xff, sizeof(antenna));
        // Fill all rssi slots with minimum value
        memset(rssi, SCHAR_MIN, sizeof(rssi));
        // Fill all noise slots with maximum value
        memset(noise, SCHAR_MAX, sizeof(noise));

        while (ret == 0 && ant_idx < RX_ANT_MAX) {
            ret = ieee80211_radiotap_iterator_next(&iterator);

            if (ret)
                continue;

            /* see if this argument is something we can use */

            switch (iterator.this_arg_index)
            {
                /*
                 * You must take care when dereferencing iterator.this_arg
                 * for multibyte types... the pointer is not aligned.  Use
                 * get_unaligned((type *)iterator.this_arg) to dereference
                 * iterator.this_arg for type "type" safely on all arches.
                 */

            case IEEE80211_RADIOTAP_ANTENNA:
                antenna[ant_idx] = *(uint8_t*)(iterator.this_arg);
                ant_idx += 1;
                break;

            case IEEE80211_RADIOTAP_CHANNEL:
                // drop channel flags - they are redundant for freq to chan convertion
                freq = le32toh(*(uint32_t*)(iterator.this_arg)) & 0xffff;
                break;

            case IEEE80211_RADIOTAP_DBM_ANTSIGNAL:
                rssi[ant_idx] = *(int8_t*)(iterator.this_arg);
                break;

            case IEEE80211_RADIOTAP_DBM_ANTNOISE:
                noise[ant_idx] = *(int8_t*)(iterator.this_arg);
                break;

            case IEEE80211_RADIOTAP_FLAGS:
                flags = *(uint8_t*)(iterator.this_arg);
                break;

            case IEEE80211_RADIOTAP_TX_FLAGS:
                self_injected = true;
                break;

            case IEEE80211_RADIOTAP_MCS:
            {
                /* u8,u8,u8 */

                uint8_t mcs_have = iterator.this_arg[0];

                if (mcs_have & IEEE80211_RADIOTAP_MCS_HAVE_MCS)
                {
                    mcs_index = iterator.this_arg[2] & 0x7f;
                }

                if ((mcs_have & 1) && (iterator.this_arg[1] & 1))
                {
                    bandwidth = 40;
                }
            }
            break;

            case IEEE80211_RADIOTAP_VHT:
            {
                /* u16 known, u8 flags, u8 bandwidth, u8 mcs_nss[4], u8 coding, u8 group_id, u16 partial_aid */
                u8 known = iterator.this_arg[0];

                if(known & 0x40)
                {
                    int bwidth = iterator.this_arg[3] & 0x1f;
                    if(bwidth >= 1 && bwidth <= 3)
                    {
                        bandwidth = 40;
                    }
                    else if(bwidth >= 4 && bwidth <= 10)
                    {
                        bandwidth = 80;
                    }
                }
                mcs_index = (iterator.this_arg[4] >> 4) & 0x0f;
            }
            break;

            default:
                break;
            }
        }  /* while more rt headers */

        if (ret != -ENOENT && ant_idx < RX_ANT_MAX){
            WFB_ERR("Error parsing radiotap header!\n");
            continue;
        }

        if (self_injected)
        {
            //ignore self injected frames
            continue;
        }

        if (flags & IEEE80211_RADIOTAP_F_FCS)
        {
            pktlen -= 4;
        }

        if (flags & IEEE80211_RADIOTAP_F_BADFCS)
        {
            WFB_ERR("Got packet with bad fsc\n");
            continue;
        }

        /* discard the radiotap header part */
        pkt += iterator._max_length;
        pktlen -= iterator._max_length;

        if (pktlen > (int)sizeof(ieee80211_header))
        {
            agg->process_packet(pkt + sizeof(ieee80211_header), pktlen - sizeof(ieee80211_header),
                                wlan_idx, antenna, rssi, noise, freq, mcs_index, bandwidth, NULL);
        } else {
            WFB_ERR("Short packet (ieee header)\n");
            continue;
        }
    }

    if (agg != NULL)
    {
        agg->observe_receiver_batch(packet_count, get_time_us() - batch_started_us);
    }
}


void ReceiverBatchStats::observe(uint32_t packet_count, uint64_t elapsed)
{
    batches += 1;
    packets += packet_count;
    elapsed_us += elapsed;
    if (elapsed > max_elapsed_us)
    {
        max_elapsed_us = elapsed;
    }
    if (packet_count > max_packets)
    {
        max_packets = packet_count;
    }
}

void ReceiverBatchStats::clear()
{
    batches = 0;
    packets = 0;
    elapsed_us = 0;
    max_elapsed_us = 0;
    max_packets = 0;
}


Aggregator::Aggregator(const string &keypair, uint64_t epoch, uint32_t channel_id, uint8_t local_node_id,
                       bool trusted_plaintext, int plaintext_fec_k, int plaintext_fec_n) : \
    count_p_all(0), count_b_all(0), count_p_dec_err(0), count_p_session(0), count_p_data(0), count_p_fec_recovered(0),
    count_p_lost(0), count_p_bad(0), count_p_override(0), count_p_outgoing(0), count_b_outgoing(0),
    grant_filter_counters_{},
    ready_filter_counters_{},
    fec_p(NULL), fec_k(-1), fec_n(-1), session_hash{}, source_states_{}, epoch(epoch), channel_id(channel_id), local_node_id(local_node_id), trusted_plaintext(trusted_plaintext), reassembly_overflow_evict_total_(0)
{
    memset(session_key, '\0', sizeof(session_key));
    memset(session_hash, '\0', sizeof(session_hash));

    if (trusted_plaintext)
    {
        if (!(plaintext_fec_k >= 1 && plaintext_fec_n >= 1 && plaintext_fec_k <= plaintext_fec_n && plaintext_fec_n < 256))
        {
            throw runtime_error("trusted_plaintext requires valid plaintext FEC k/n");
        }
        init_fec(plaintext_fec_k, plaintext_fec_n);
        return;
    }

    FILE *fp;
    if((fp = fopen(keypair.c_str(), "r")) == NULL)
    {
        throw runtime_error(string_format("Unable to open %s: %s", keypair.c_str(), strerror(errno)));
    }
    if (fread(rx_secretkey, crypto_box_SECRETKEYBYTES, 1, fp) != 1)
    {
        fclose(fp);
        throw runtime_error(string_format("Unable to read rx secret key: %s", strerror(errno)));
    }
    if (fread(tx_publickey, crypto_box_PUBLICKEYBYTES, 1, fp) != 1)
    {
        fclose(fp);
        throw runtime_error(string_format("Unable to read tx public key: %s", strerror(errno)));
    }
    fclose(fp);
}


Aggregator::~Aggregator()
{
    if (fec_p != NULL)
    {
        deinit_fec();
    }
}

void Aggregator::init_fec(int k, int n)
{
    assert(fec_p == NULL);
    assert(k >= 1);
    assert(n >= 1);
    assert(n < 256);
    assert(k <= n);

    fec_k = k;
    fec_n = n;

    zfex_status_code_t rc = fec_new(fec_k, fec_n, &fec_p);
    assert(rc == ZFEX_SC_OK);

    memset(source_states_, '\0', sizeof(source_states_));
}

void Aggregator::deinit_fec(void)
{
    assert(fec_p != NULL);

    clear_source_states();

    zfex_status_code_t rc = fec_free(fec_p);
    assert(rc == ZFEX_SC_OK);
    fec_p = NULL;
    fec_k = -1;
    fec_n = -1;
}

void Aggregator::init_source_state(rx_source_state_t *state, uint8_t source_node)
{
    assert(state != NULL);
    assert(source_node != 0);

    state->source_node = source_node;
    state->seq = 0;
    state->has_session = false;
    state->session_id = 0;
    state->retired_sessions.clear();
    state->rx_ring_front = 0;
    state->rx_ring_alloc = 0;
    state->stats = {};
    state->last_known_block = (uint64_t)-1;

    for(int ring_idx = 0; ring_idx < RX_RING_SIZE; ring_idx++)
    {
        state->rx_ring[ring_idx].block_idx = 0;
        state->rx_ring[ring_idx].fragment_to_send_idx = 0;
        state->rx_ring[ring_idx].has_fragments = 0;
        state->rx_ring[ring_idx].fragments = new uint8_t*[fec_n];
        for(int i=0; i < fec_n; i++)
        {
            int rc = posix_memalign((void**)&state->rx_ring[ring_idx].fragments[i], ZFEX_SIMD_ALIGNMENT, ZFEX_ROUND_UP_SIMD(MAX_FEC_PAYLOAD));
            assert(rc == 0);
        }
        state->rx_ring[ring_idx].fragment_map = new size_t[fec_n];
        memset(state->rx_ring[ring_idx].fragment_map, '\0', fec_n * sizeof(size_t));
    }
}

void Aggregator::deinit_source_state(rx_source_state_t *state)
{
    assert(state != NULL);
    for (int ring_idx = 0; ring_idx < RX_RING_SIZE; ring_idx++)
    {
        delete[] state->rx_ring[ring_idx].fragment_map;
        state->rx_ring[ring_idx].fragment_map = NULL;
        for (int i = 0; i < fec_n; i++)
        {
            free(state->rx_ring[ring_idx].fragments[i]);
        }
        delete[] state->rx_ring[ring_idx].fragments;
        state->rx_ring[ring_idx].fragments = NULL;
    }
}

void Aggregator::reset_source_reassembly(rx_source_state_t *state)
{
    assert(state != NULL);
    state->seq = 0;
    state->rx_ring_front = 0;
    state->rx_ring_alloc = 0;
    state->last_known_block = (uint64_t)-1;
    for (int ring_idx = 0; ring_idx < RX_RING_SIZE; ring_idx++)
    {
        state->rx_ring[ring_idx].block_idx = 0;
        state->rx_ring[ring_idx].fragment_to_send_idx = 0;
        state->rx_ring[ring_idx].has_fragments = 0;
        memset(state->rx_ring[ring_idx].fragment_map, '\0', fec_n * sizeof(size_t));
    }
}

bool Aggregator::accept_data_session(rx_source_state_t *state, uint64_t session_id, uint64_t block_idx)
{
    assert(state != NULL);
    if (session_id == 0) return false;
    if (state->has_session && state->session_id != session_id)
    {
        if (state->retired_sessions.count(session_id) != 0)
        {
            WFB_ERR("DATA_REJECT reason=retired_session source_node=%u source_local_block_idx=0x%" PRIx64 " session_id=0x%" PRIx64 "\n",
                    static_cast<unsigned>(state->source_node), block_idx, session_id);
            return false;
        }
        state->retired_sessions.insert(state->session_id);
        reset_source_reassembly(state);
    }
    state->has_session = true;
    state->session_id = session_id;
    return true;
}

void Aggregator::clear_source_states(void)
{
    for(size_t i = 0; i < 256; i++)
    {
        if (source_states_[i] == NULL)
        {
            continue;
        }
        deinit_source_state(source_states_[i]);
        delete source_states_[i];
        source_states_[i] = NULL;
    }
}

rx_source_state_t *Aggregator::get_source_state(uint8_t source_node, bool create_if_missing)
{
    if (source_node == 0)
    {
        return NULL;
    }

    rx_source_state_t *state = source_states_[source_node];
    if (state == NULL && create_if_missing)
    {
        state = new rx_source_state_t();
        init_source_state(state, source_node);
        source_states_[source_node] = state;
    }
    return state;
}


Forwarder::Forwarder(const string &client_addr, int client_port, int snd_buf_size)
{
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) throw std::runtime_error(string_format("Error opening socket: %s", strerror(errno)));

    if (snd_buf_size > 0)
    {
        if(setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, (const void *)&snd_buf_size , sizeof(snd_buf_size)) !=0)
        {
            close(sockfd);
            throw runtime_error(string_format("Unable to set SO_SNDBUF: %s", strerror(errno)));
        }
    }

    memset(&saddr, '\0', sizeof(saddr));
    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = inet_addr(client_addr.c_str());
    saddr.sin_port = htons((unsigned short)client_port);
}


void Forwarder::process_packet(const uint8_t *buf, size_t size, uint8_t wlan_idx, const uint8_t *antenna,
                               const int8_t *rssi, const int8_t *noise, uint16_t freq, uint8_t mcs_index,
                               uint8_t bandwidth, sockaddr_in *sockaddr)
{
    wrxfwd_t fwd_hdr = { .wlan_idx = wlan_idx,
                         .freq = htons(freq),
                         .mcs_index = mcs_index,
                         .bandwidth = bandwidth };

    memcpy(fwd_hdr.antenna, antenna, RX_ANT_MAX * sizeof(uint8_t));
    memcpy(fwd_hdr.rssi, rssi, RX_ANT_MAX * sizeof(int8_t));
    memcpy(fwd_hdr.noise, noise, RX_ANT_MAX * sizeof(int8_t));

    struct iovec iov[2] = {{ .iov_base = (void*)&fwd_hdr,
                             .iov_len = sizeof(fwd_hdr)},
                           { .iov_base = (void*)buf,
                             .iov_len = size }};

    struct msghdr msghdr = { .msg_name = &saddr,
                             .msg_namelen = sizeof(saddr),
                             .msg_iov = iov,
                             .msg_iovlen = 2,
                             .msg_control = NULL,
                             .msg_controllen = 0,
                             .msg_flags = 0 };

    sendmsg(sockfd, &msghdr, MSG_DONTWAIT);
}


Forwarder::~Forwarder()
{
    close(sockfd);
}

int Aggregator::rx_ring_push(rx_source_state_t *state)
{
    assert(state != NULL);

    if(state->rx_ring_alloc < RX_RING_SIZE)
    {
        int idx = modN(state->rx_ring_front + state->rx_ring_alloc, RX_RING_SIZE);
        state->rx_ring_alloc += 1;
        return idx;
    }

    WFB_DBG("AGG: Override source=%u block 0x%" PRIx64 " flush %d fragments\n",
            static_cast<unsigned>(state->source_node),
            state->rx_ring[state->rx_ring_front].block_idx,
            state->rx_ring[state->rx_ring_front].has_fragments);
    const uint64_t evicted_block_idx = state->rx_ring[state->rx_ring_front].block_idx;
    const unsigned evicted_has_fragments = state->rx_ring[state->rx_ring_front].has_fragments > 0 ? 1U : 0U;
    reassembly_overflow_evict_total_ += 1;
    WFB_ERR("REASSEMBLY_OVERFLOW_EVICT source_node=%u evicted_block_idx=0x%" PRIx64 " evicted_has_fragments=%u unfinished_blocks=%d unfinished_block_limit=%u total=%" PRIu64 "\n",
            static_cast<unsigned>(state->source_node),
            evicted_block_idx,
            evicted_has_fragments,
            state->rx_ring_alloc,
            unfinished_block_limit(),
            reassembly_overflow_evict_total_);

    count_p_override += 1;

    for(int f_idx=state->rx_ring[state->rx_ring_front].fragment_to_send_idx; f_idx < fec_k; f_idx++)
    {
        if(state->rx_ring[state->rx_ring_front].fragment_map[f_idx])
        {
            send_packet(state, state->rx_ring_front, f_idx);
        }
    }

    int ring_idx = state->rx_ring_front;
    state->rx_ring_front = modN(state->rx_ring_front + 1, RX_RING_SIZE);
    return ring_idx;
}


int Aggregator::get_block_ring_idx(rx_source_state_t *state, uint64_t block_idx)
{
    assert(state != NULL);

    for(int i = state->rx_ring_front, c = state->rx_ring_alloc; c > 0; i = modN(i + 1, RX_RING_SIZE), c--)
    {
        if (state->rx_ring[i].block_idx == block_idx) return i;
    }

    if (state->last_known_block != (uint64_t)-1 && block_idx <= state->last_known_block)
    {
        return -1;
    }

    int new_blocks = (int)min(state->last_known_block != (uint64_t)-1 ? block_idx - state->last_known_block : 1, (uint64_t)RX_RING_SIZE);
    assert (new_blocks > 0);

    state->last_known_block = block_idx;
    int ring_idx = -1;

    for(int i = 0; i < new_blocks; i++)
    {
        ring_idx = rx_ring_push(state);
        state->rx_ring[ring_idx].block_idx = block_idx + i + 1 - new_blocks;
        state->rx_ring[ring_idx].fragment_to_send_idx = 0;
        state->rx_ring[ring_idx].has_fragments = 0;
        memset(state->rx_ring[ring_idx].fragment_map, '\0', fec_n * sizeof(size_t));
    }
    return ring_idx;
}

void Aggregator::observe_receiver_batch(uint32_t packet_count, uint64_t elapsed_us)
{
    receiver_batch_stats.observe(packet_count, elapsed_us);
}

void Aggregator::dump_stats(void)
{
    //timestamp in ms
    uint64_t ts = get_time_ms();

    for(auto it = antenna_stat.begin(); it != antenna_stat.end(); it++)
    {
        IPC_MSG("%" PRIu64 "\tRX_ANT\t%u:%u:%u\t%" PRIx64 "\t%d" ":%d:%d:%d" ":%d:%d:%d\n",
                ts, it->first.freq, it->first.mcs_index, it->first.bandwidth, it->first.antenna_id, it->second.count_all,
                it->second.rssi_min, it->second.rssi_sum / it->second.count_all, it->second.rssi_max,
                it->second.snr_min, it->second.snr_sum / it->second.count_all, it->second.snr_max);
    }

    IPC_MSG("%" PRIu64 "\tPKT\t%u:%u:%u:%u:%u:%u:%u:%u:%u:%u:%u\n", ts,
            count_p_all, count_b_all,                    // incoming
            count_p_dec_err,                             // decryption
            count_p_session, count_p_data,               // classification
            (uint32_t)count_p_uniq.size(),               // unique check
            count_p_fec_recovered, count_p_lost,         // fec recovering
            count_p_bad,                                 // internal errors
            count_p_outgoing, count_b_outgoing);         // outgoing
    IPC_MSG("%" PRIu64 "\tRX_BATCH\t%" PRIu64 ":%" PRIu64 ":%" PRIu64 ":%" PRIu64 ":%" PRIu64 "\n",
            ts,
            receiver_batch_stats.batches,
            receiver_batch_stats.packets,
            receiver_batch_stats.elapsed_us,
            receiver_batch_stats.max_elapsed_us,
            receiver_batch_stats.max_packets);

    std::set<uint8_t> nodes_to_report = known_client_node_ids_;
    for(size_t i = 1; i < 256; i++)
    {
        if (source_states_[i] != NULL)
        {
            nodes_to_report.insert(static_cast<uint8_t>(i));
        }
    }

    for(uint8_t node_id : nodes_to_report)
    {
        rx_source_state_t *state = source_states_[node_id];
        uint32_t raw_p = (state != NULL) ? state->stats.count_p_raw : 0;
        uint32_t raw_b = (state != NULL) ? state->stats.count_b_raw : 0;
        uint32_t fec_rec = (state != NULL) ? state->stats.count_p_fec_recovered : 0;
        uint32_t lost = (state != NULL) ? state->stats.count_p_lost : 0;
        uint32_t out_p = (state != NULL) ? state->stats.count_p_outgoing : 0;
        uint32_t out_b = (state != NULL) ? state->stats.count_b_outgoing : 0;

        IPC_MSG("%" PRIu64 "\tPKT_SRC\t%u:%u:%u:%u:%u:%u:%u\n", ts,
                static_cast<unsigned>(node_id),
                raw_p, raw_b, fec_rec, lost, out_p, out_b);
    }
    IPC_MSG("%" PRIu64 "\tGRANT_FILTER\t%u:%u:%u:%u:%u:%u:%u:%u:%u\n", ts,
            grant_filter_counters_.received,
            grant_filter_counters_.accepted,
            grant_filter_counters_.ignored_invalid_source,
            grant_filter_counters_.ignored_wrong_target,
            grant_filter_counters_.ignored_duplicate_sequence,
            grant_filter_counters_.ignored_stale_sequence,
            grant_filter_counters_.ignored_expired,
            grant_filter_counters_.ignored_invalid_session,
            grant_filter_counters_.ignored_retired_session);
    IPC_MSG("%" PRIu64 "\tREADY_FILTER\t%u:%u:%u:%u:%u\n", ts,
            ready_filter_counters_.received,
            ready_filter_counters_.accepted,
            ready_filter_counters_.rejected.invalid_source,
            ready_filter_counters_.rejected.wrong_ingress_or_link_domain,
            ready_filter_counters_.rejected.unknown_client);
    IPC_MSG("%" PRIu64 "\tREASSEMBLY\t%" PRIu64 ":%u\n", ts,
            reassembly_overflow_evict_total_,
            unfinished_block_limit());
    IPC_MSG_SEND();

    if(count_p_override)
    {
        WFB_ERR("REASSEMBLY_OVERFLOW_SUMMARY interval_evict=%u total=%" PRIu64 " unfinished_block_limit=%u\n",
                count_p_override,
                reassembly_overflow_evict_total_,
                unfinished_block_limit());
    }

    if(count_p_lost)
    {
        WFB_ERR("%u packets lost\n", count_p_lost);
    }

    clear_stats();
}

void Aggregator::clear_stats(void)
{
    antenna_stat.clear();
    count_p_all = 0;
    count_b_all = 0;
    count_p_dec_err = 0;
    count_p_session = 0;
    count_p_data = 0;
    count_p_uniq.clear();
    count_p_fec_recovered = 0;
    count_p_lost = 0;
    count_p_bad = 0;
    count_p_override = 0;
    count_p_outgoing = 0;
    count_b_outgoing = 0;
    receiver_batch_stats.clear();

    for(size_t i = 1; i < 256; i++)
    {
        if (source_states_[i] != NULL)
        {
            memset(&source_states_[i]->stats, 0, sizeof(source_states_[i]->stats));
        }
    }
}

bool Aggregator::get_source_stats(uint8_t source_node, RxSourceStats *stats) const
{
    if (source_node == 0 || source_states_[source_node] == NULL)
    {
        return false;
    }
    if (stats != NULL)
    {
        *stats = source_states_[source_node]->stats;
    }
    return true;
}


void Aggregator::log_rssi(const sockaddr_in *sockaddr, uint8_t wlan_idx, const uint8_t *ant, const int8_t *rssi, const int8_t *noise,
                          uint16_t freq, uint8_t mcs_index, uint8_t bandwidth)
{
    for(int i = 0; i < RX_ANT_MAX && ant[i] != 0xff; i++)
    {
        // antenna_id: addr + port + wlan_idx + ant
        rxAntennaKey key = {.freq = freq,
                            .antenna_id = 0,
                            .mcs_index=mcs_index,
                            .bandwidth=bandwidth};

        if (sockaddr != NULL && sockaddr->sin_family == AF_INET)
        {
            // We ignore port here because for the one host (wlan_idx, antenna_id) will be unique key for all forwarder processes.
            key.antenna_id = ((uint64_t)ntohl(sockaddr->sin_addr.s_addr) << 32);
        }

        key.antenna_id |= ((uint64_t)wlan_idx << 8 | (uint64_t)ant[i]);

        antenna_stat[key].log_rssi(rssi[i], noise[i]);
    }
}

// cppcheck-suppress unusedFunction
int Aggregator::get_tag(const void *buf, size_t size, uint8_t tag_id, void *value, size_t value_size)
{
    tlv_hdr_t *p = (tlv_hdr_t*)buf;
    void *end = (uint8_t*)buf + size;

    while((void*)(p + 1) <= end)
    {
        if(p->id != tag_id)
        {
            p = (tlv_hdr_t*)((uint8_t*)(p + 1) + p->len);
            continue;
        }
        if(p->len > value_size) return -1;
        if(p->value + p->len > end) return -1;
        memcpy(value, p->value, p->len);
        return p->len;
    }

    return -1;
}

void Aggregator::process_packet(const uint8_t *buf, size_t size, uint8_t wlan_idx, const uint8_t *antenna,
                                const int8_t *rssi, const int8_t *noise, uint16_t freq, uint8_t mcs_index,
                                uint8_t bandwidth, sockaddr_in *sockaddr)
{
    uint8_t session_tmp[MAX_SESSION_PACKET_SIZE - crypto_box_MACBYTES - sizeof(wsession_hdr_t)];
    uint8_t new_session_hash[sizeof(session_hash)];

    wsession_data_t* new_session_data = NULL;
    //size_t new_session_tags_size = 0;

    count_p_all += 1;
    count_b_all += size;

    if(size == 0) return;

    if (size > MAX_FORWARDER_PACKET_SIZE)
    {
        WFB_ERR("Long packet (fec payload)\n");
        count_p_bad += 1;
        return;
    }

    switch(buf[0])
    {
    case WFB_PACKET_DATA:
        if(size < sizeof(wblock_hdr_t) + sizeof(wpacket_hdr_t) + (trusted_plaintext ? 0 : crypto_aead_chacha20poly1305_ABYTES))
        {
            WFB_ERR("Short packet (fec header)\n");
            count_p_bad += 1;
            return;
        }
        {
            const wblock_hdr_t *header = reinterpret_cast<const wblock_hdr_t *>(buf);
            if (be16toh(header->magic) != WFB_DATA_MAGIC || header->version != WFB_DATA_VERSION ||
                be64toh(header->session_id) == 0)
            {
                WFB_ERR("DATA_REJECT reason=invalid_protocol_or_session\n");
                count_p_bad += 1;
                return;
            }
        }
        break;

    case WFB_PACKET_SESSION:
        if (trusted_plaintext)
        {
            WFB_ERR("Unexpected session packet in trusted_plaintext\n");
            count_p_bad += 1;
            return;
        }

        new_session_data = (wsession_data_t*)session_tmp;

        if(size < sizeof(wsession_hdr_t) + sizeof(wsession_data_t) + crypto_box_MACBYTES || \
           size > MAX_SESSION_PACKET_SIZE)
        {
            WFB_ERR("Invalid session key packet\n");
            count_p_bad += 1;
            return;
        }

        if(crypto_generichash(new_session_hash,
                              sizeof(new_session_hash),
                              buf + sizeof(wsession_hdr_t),
                              size - sizeof(wsession_hdr_t),
                              ((wsession_hdr_t*)buf)->session_nonce,
                              sizeof(((wsession_hdr_t*)buf)->session_nonce)) != 0)
        {
            assert(0);
        }

        if (memcmp(session_hash, new_session_hash, sizeof(session_hash)) == 0)
        {
            count_p_session += 1;
            return;
        }

        if(crypto_box_open_easy((uint8_t*)session_tmp,
                                buf + sizeof(wsession_hdr_t),
                                size - sizeof(wsession_hdr_t),
                                ((wsession_hdr_t*)buf)->session_nonce,
                                tx_publickey, rx_secretkey) != 0)
        {
            WFB_ERR("Unable to decrypt session key\n");
            count_p_dec_err += 1;
            return;
        }

        if (be64toh(new_session_data->epoch) < epoch)
        {
            WFB_ERR("Session epoch doesn't match: %" PRIu64 " < %" PRIu64 "\n", be64toh(new_session_data->epoch), epoch);
            count_p_dec_err += 1;
            return;
        }

        if (be32toh(new_session_data->channel_id) != channel_id)
        {
            WFB_ERR("Session channel_id doesn't match: %u != %u\n", be32toh(new_session_data->channel_id), channel_id);
            count_p_dec_err += 1;
            return;
        }

        if (new_session_data->fec_type != WFB_FEC_VDM_RS)
        {
            WFB_ERR("Unsupported FEC codec type: %d\n", new_session_data->fec_type);
            count_p_dec_err += 1;
            return;
        }

        if (new_session_data->n < 1)
        {
            WFB_ERR("Invalid FEC N: %d\n", new_session_data->n);
            count_p_dec_err += 1;
            return;
        }

        if (new_session_data->k < 1 || new_session_data->k > new_session_data->n)
        {
            WFB_ERR("Invalid FEC K: %d\n", new_session_data->k);
            count_p_dec_err += 1;
            return;
        }

        count_p_session += 1;

        if (memcmp(session_key, new_session_data->session_key, sizeof(session_key)) != 0)
        {
            epoch = be64toh(new_session_data->epoch);
            memcpy(session_key, new_session_data->session_key, sizeof(session_key));

            if (fec_p != NULL)
            {
                deinit_fec();
            }

            init_fec(new_session_data->k, new_session_data->n);

            IPC_MSG("%" PRIu64 "\tSESSION\t%" PRIu64 ":%u:%d:%d\n", get_time_ms(), epoch, WFB_FEC_VDM_RS, fec_k, fec_n);
            IPC_MSG_SEND();
        }

        memcpy(session_hash, new_session_hash, sizeof(session_hash));
        return;

    case WFB_PACKET_CONTROL:
    {
        ControlEnvelopeView envelope = {};
        uint64_t now_ms = get_time_ms();
        ControlEnvelopeParseStatus status = parse_control_envelope(buf, size, now_ms, &envelope);
        if (status != ControlEnvelopeParseStatus::ok)
        {
            WFB_ERR("Invalid control envelope\n");
            count_p_bad += 1;
            return;
        }

        if (envelope.control_type == WFB_CONTROL_TYPE_GRANT)
        {
            GrantDecision decision = filter_grant(envelope,
                                                  true, // is_valid_source
                                                  local_node_id,
                                                  now_ms,
                                                  &grant_filter_state_,
                                                  &grant_filter_counters_);
            if (decision != GrantDecision::accept)
            {
                return;
            }
            if (token_control_listener_ != NULL)
            {
                token_control_listener_->on_token_control(envelope);
            }
        }
        else if (envelope.control_type == WFB_CONTROL_TYPE_READY)
        {
            bool is_valid_ingress = true; // 当前入口已按链路域分流；后续多入口时再细化
            bool is_known_client = known_client_node_ids_.count(envelope.source_node) != 0;
            ReadyDecision decision = filter_ready(envelope, is_valid_ingress, is_known_client, &ready_filter_counters_);
            if (decision != ReadyDecision::accept)
            {
                log_ready_rejection(envelope, decision, local_node_id, "rx_control");
                return;
            }
            if (token_control_listener_ != NULL)
            {
                token_control_listener_->on_token_control(envelope);
            }
        }
        return;
    }

    default:
        WFB_ERR("Unknown packet type 0x%x\n", buf[0]);
        count_p_bad += 1;
        return;
    }

    uint8_t decrypted[MAX_FEC_PAYLOAD];
    unsigned long long decrypted_len;
    wblock_hdr_t *block_hdr = (wblock_hdr_t*)buf;

    if (trusted_plaintext)
    {
        decrypted_len = size - sizeof(wblock_hdr_t);
        memcpy(decrypted, buf + sizeof(wblock_hdr_t), decrypted_len);
    }
    else if (crypto_aead_chacha20poly1305_decrypt(decrypted, &decrypted_len,
                                                  NULL,
                                                  buf + sizeof(wblock_hdr_t), size - sizeof(wblock_hdr_t),
                                                  buf,
                                                  sizeof(wblock_hdr_t),
                                                  (uint8_t*)(&(block_hdr->data_nonce)), session_key) != 0)
    {
        WFB_ERR("Unable to decrypt packet #0x%" PRIx64 "\n", be64toh(block_hdr->data_nonce));
        count_p_dec_err += 1;
        return;
    }

    count_p_data += 1;
    log_rssi(sockaddr, wlan_idx, antenna, rssi, noise, freq, mcs_index, bandwidth);

    assert(decrypted_len >= sizeof(wpacket_hdr_t));
    assert(decrypted_len <= MAX_FEC_PAYLOAD);

    const uint64_t data_nonce = be64toh(block_hdr->data_nonce);
    const uint8_t source_node = data_nonce_source_node(data_nonce);
    const uint64_t block_idx = data_nonce_source_local_block_idx(data_nonce);
    const uint8_t fragment_idx = data_nonce_fragment_idx(data_nonce);

    count_p_uniq.insert(std::make_pair(be64toh(block_hdr->session_id), data_nonce));

    if (source_node == 0)
    {
        log_data_rejection("invalid_source_node", source_node, block_idx, local_node_id);
        count_p_bad += 1;
        return;
    }

    if (!known_client_node_ids_.empty() && known_client_node_ids_.count(source_node) == 0)
    {
        log_data_rejection("unknown_client", source_node, block_idx, local_node_id);
        return;
    }

    if (fragment_idx >= fec_n)
    {
        WFB_ERR("Invalid fragment_idx: %d\n", fragment_idx);
        count_p_bad += 1;
        return;
    }

    rx_source_state_t *state = get_source_state(source_node, true);
    assert(state != NULL);

    if (!accept_data_session(state, be64toh(block_hdr->session_id), block_idx)) return;

    state->stats.count_p_raw += 1;
    state->stats.count_b_raw += size;

    int ring_idx = get_block_ring_idx(state, block_idx);

    if (ring_idx < 0) return;

    rx_ring_item_t *p = &state->rx_ring[ring_idx];

    if (p->fragment_map[fragment_idx]) return;

    memset(p->fragments[fragment_idx], '\0', MAX_FEC_PAYLOAD);
    memcpy(p->fragments[fragment_idx], decrypted, decrypted_len);

    p->fragment_map[fragment_idx] = decrypted_len;
    p->has_fragments += 1;

    if(ring_idx == state->rx_ring_front)
    {
        while(p->fragment_to_send_idx < fec_k && p->fragment_map[p->fragment_to_send_idx])
        {
            send_packet(state, ring_idx, p->fragment_to_send_idx);
            p->fragment_to_send_idx += 1;
        }

        if(p->fragment_to_send_idx == fec_k)
        {
            state->rx_ring_front = modN(state->rx_ring_front + 1, RX_RING_SIZE);
            state->rx_ring_alloc -= 1;
            assert(state->rx_ring_alloc >= 0);
            return;
        }
    }

    if(p->fragment_to_send_idx < fec_k && p->has_fragments == fec_k)
    {
        int nrm = modN(ring_idx - state->rx_ring_front, RX_RING_SIZE);

        while(nrm > 0)
        {
            for(int f_idx=state->rx_ring[state->rx_ring_front].fragment_to_send_idx; f_idx < fec_k; f_idx++)
            {
                if(state->rx_ring[state->rx_ring_front].fragment_map[f_idx])
                {
                    send_packet(state, state->rx_ring_front, f_idx);
                }
            }
            state->rx_ring_front = modN(state->rx_ring_front + 1, RX_RING_SIZE);
            state->rx_ring_alloc -= 1;
            nrm -= 1;
        }

        assert(state->rx_ring_alloc > 0);
        assert(ring_idx == state->rx_ring_front);

        for(int f_idx=p->fragment_to_send_idx; f_idx < fec_k; f_idx++)
        {
            if(! p->fragment_map[f_idx])
            {
                uint32_t fec_count = 0;

                apply_fec(state, ring_idx);

                for(; f_idx < fec_k; f_idx++)
                {
                    if(! p->fragment_map[f_idx])
                    {
                        fec_count += 1;
                    }
                }

                if(fec_count)
                {
                    count_p_fec_recovered += fec_count;
                    state->stats.count_p_fec_recovered += fec_count;
                    WFB_DBG("FEC recovered %u packets\n", fec_count);
                }
                break;
            }
        }

        while(p->fragment_to_send_idx < fec_k)
        {
            send_packet(state, ring_idx, p->fragment_to_send_idx);
            p->fragment_to_send_idx += 1;
        }

        state->rx_ring_front = modN(state->rx_ring_front + 1, RX_RING_SIZE);
        state->rx_ring_alloc -= 1;
        assert(state->rx_ring_alloc >= 0);
    }
}

void Aggregator::send_packet(rx_source_state_t *state, int ring_idx, int fragment_idx)
{
    assert(state != NULL);

    wpacket_hdr_t* packet_hdr = (wpacket_hdr_t*)(state->rx_ring[ring_idx].fragments[fragment_idx]);
    uint8_t *payload = (state->rx_ring[ring_idx].fragments[fragment_idx]) + sizeof(wpacket_hdr_t);
    uint8_t flags = packet_hdr->flags;
    uint16_t packet_size = be16toh(packet_hdr->packet_size);
    uint32_t packet_seq = (uint32_t)(state->rx_ring[ring_idx].block_idx * fec_k + fragment_idx);

    if (packet_seq > state->seq + 1 && state->seq > 0)
    {
        uint32_t lost_count = packet_seq - state->seq - 1;
        ANDROID_IPC_MSG("PKT_LOST\t%d", lost_count);
        count_p_lost += lost_count;
        state->stats.count_p_lost += lost_count;

        WFB_ERR("PACKET_LOSS source_node=%u previous_seq=%" PRIu32 " current_seq=%" PRIu32 " lost_count=%" PRIu32 "\n",
                static_cast<unsigned>(state->source_node),
                state->seq,
                packet_seq,
                lost_count);
        if (packet_loss_listener_ != NULL)
        {
            packet_loss_listener_->on_packet_loss(lost_count, state->seq, packet_seq);
        }
    }

    state->seq = packet_seq;

    if(packet_size > MAX_PAYLOAD_SIZE)
    {
        WFB_ERR("Corrupted packet %u\n", state->seq);
        count_p_bad += 1;
    }
    else if(!(flags & WFB_PACKET_FEC_ONLY))
    {
        send_to_socket(payload, packet_size);
        count_p_outgoing += 1;
        count_b_outgoing += packet_size;
        state->stats.count_p_outgoing += 1;
        state->stats.count_b_outgoing += packet_size;
    }
}

void Aggregator::apply_fec(rx_source_state_t *state, int ring_idx)
{
    assert(state != NULL);
    assert(fec_k >= 1);
    assert(fec_n >= 1);
    assert(fec_k <= fec_n);
    assert(fec_p != NULL);

    unsigned index[fec_k];
    uint8_t *in_blocks[fec_k];
    uint8_t *out_blocks[fec_n - fec_k];
    int j = fec_k;
    int ob_idx = 0;
    size_t max_packet_size = 0;

    for(int i=0; i < fec_k; i++)
    {
        if(state->rx_ring[ring_idx].fragment_map[i])
        {
            in_blocks[i] = state->rx_ring[ring_idx].fragments[i];
            index[i] = i;
        }
        else
        {
            while(j < fec_n && ! state->rx_ring[ring_idx].fragment_map[j])
            {
                j++;
            }

            assert(j < fec_n);
            max_packet_size = max(max_packet_size, state->rx_ring[ring_idx].fragment_map[j]);
            in_blocks[i] = state->rx_ring[ring_idx].fragments[j];
            out_blocks[ob_idx++] = state->rx_ring[ring_idx].fragments[i];
            index[i] = j++;
        }
    }

    assert(max_packet_size > 0);
    assert(max_packet_size <= MAX_FEC_PAYLOAD);

    zfex_status_code_t rc = fec_decode_simd(fec_p, (const uint8_t**)in_blocks, out_blocks, index, ZFEX_ROUND_UP_SIMD(max_packet_size));
    assert(rc == ZFEX_SC_OK);
}

AggregatorUDPv4::AggregatorUDPv4(const std::string &client_addr, int client_port, const std::string &keypair, uint64_t epoch, uint32_t channel_id,
                                 int snd_buf_size, uint8_t local_node_id, bool trusted_plaintext, int plaintext_fec_k, int plaintext_fec_n) : \
    Aggregator(keypair, epoch, channel_id, local_node_id, trusted_plaintext, plaintext_fec_k, plaintext_fec_n)
{
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) throw std::runtime_error(string_format("Error opening socket: %s", strerror(errno)));

    if (snd_buf_size > 0)
    {
        if(setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, (const void *)&snd_buf_size , sizeof(snd_buf_size)) !=0)
        {
            close(sockfd);
            throw runtime_error(string_format("Unable to set SO_SNDBUF: %s", strerror(errno)));
        }
    }

    memset(&saddr, '\0', sizeof(saddr));
    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = inet_addr(client_addr.c_str());
    saddr.sin_port = htons((unsigned short)client_port);
}

AggregatorUDPv4::~AggregatorUDPv4()
{
    close(sockfd);
}

void AggregatorUDPv4::send_to_socket(const uint8_t *payload, uint16_t packet_size)
{
    sendto(sockfd, payload, packet_size, MSG_DONTWAIT, (sockaddr*)&saddr, sizeof(saddr));
}

AggregatorUNIX::AggregatorUNIX(const std::string &socket_path, const std::string &keypair, uint64_t epoch, uint32_t channel_id,
                               int snd_buf_size, uint8_t local_node_id, bool trusted_plaintext, int plaintext_fec_k, int plaintext_fec_n) : \
    Aggregator(keypair, epoch, channel_id, local_node_id, trusted_plaintext, plaintext_fec_k, plaintext_fec_n)
{
    sockfd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (sockfd < 0) throw std::runtime_error(string_format("Error opening socket: %s", strerror(errno)));

    if (snd_buf_size > 0)
    {
        if(setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, (const void *)&snd_buf_size , sizeof(snd_buf_size)) !=0)
        {
            close(sockfd);
            throw runtime_error(string_format("Unable to set SO_SNDBUF: %s", strerror(errno)));
        }
    }

    memset(&saddr, '\0', sizeof(saddr));
    saddr.sun_family = AF_UNIX;
    strncpy(saddr.sun_path + 1, socket_path.c_str(), sizeof(saddr.sun_path) - 2);
}

AggregatorUNIX::~AggregatorUNIX()
{
    close(sockfd);
}

void AggregatorUNIX::send_to_socket(const uint8_t *payload, uint16_t packet_size)
{
    sendto(sockfd, payload, packet_size, MSG_DONTWAIT, (sockaddr*)&saddr, sizeof(sa_family_t) + strlen(saddr.sun_path + 1) + 1);
}

void radio_loop(int argc, char* const *argv, int optind, uint32_t channel_id, unique_ptr<BaseAggregator> &agg, int log_interval, int rcv_buf_size)
{
    int nfds = argc - optind;
    uint64_t log_send_ts = get_time_ms();
    struct pollfd fds[MAX_RX_INTERFACES];
    unique_ptr<Receiver> rx[MAX_RX_INTERFACES];

    if (nfds > MAX_RX_INTERFACES)
    {
        throw runtime_error(string_format("Too many WiFi adapters, increase MAX_RX_INTERFACES"));
    }

    memset(fds, '\0', sizeof(fds));

    for(int i = 0; i < nfds; i++)
    {
        rx[i].reset(new Receiver(argv[optind + i], i, channel_id, agg.get(), rcv_buf_size));
        fds[i].fd = rx[i]->getfd();
        fds[i].events = POLLIN;
    }

    for(;;)
    {
        uint64_t cur_ts = get_time_ms();
        int rc = poll(fds, nfds, log_send_ts > cur_ts ? log_send_ts - cur_ts : 0);

        if (rc < 0){
            if (errno == EINTR || errno == EAGAIN) continue;
            throw runtime_error(string_format("Poll error: %s", strerror(errno)));
        }

        cur_ts = get_time_ms();
        if (cur_ts >= log_send_ts)
        {
            agg->dump_stats();
            log_send_ts = cur_ts + log_interval - ((cur_ts - log_send_ts) % log_interval);
        }

        if (rc == 0) continue; // timeout expired

        for(int i = 0; rc > 0 && i < nfds; i++)
        {
            if (fds[i].revents & (POLLERR|POLLNVAL))
            {
                throw runtime_error("socket error!");
            }
            if (fds[i].revents & POLLIN){
                rx[i]->loop_iter();
                rc -= 1;
            }
        }
    }
}

void network_loop(int srv_port, unique_ptr<BaseAggregator> &agg, int log_interval, int rcv_buf_size)
{
    wrxfwd_t fwd_hdr;
    struct sockaddr_in sockaddr;
    uint8_t buf[MAX_FORWARDER_PACKET_SIZE];

    uint64_t log_send_ts = get_time_ms();
    struct pollfd fds[1];
    int fd = open_udp_socket_for_rx(srv_port, rcv_buf_size);

    memset(fds, '\0', sizeof(fds));
    fds[0].fd = fd;
    fds[0].events = POLLIN;

    for(;;)
    {
        uint64_t cur_ts = get_time_ms();
        int rc = poll(fds, 1, log_send_ts > cur_ts ? log_send_ts - cur_ts : 0);

        if (rc < 0){
            if (errno == EINTR || errno == EAGAIN) continue;
            throw runtime_error(string_format("poll error: %s", strerror(errno)));
        }

        cur_ts = get_time_ms();
        if (cur_ts >= log_send_ts)
        {
            agg->dump_stats();
            log_send_ts = cur_ts + log_interval - ((cur_ts - log_send_ts) % log_interval);
        }

        if (rc == 0) continue; // timeout expired

        // some events detected
        if (fds[0].revents & (POLLERR | POLLNVAL))
        {
            throw runtime_error(string_format("socket error: %s", strerror(errno)));
        }

        if (fds[0].revents & POLLIN)
        {
            for(;;) // process pending rx
            {
                memset((void*)&sockaddr, '\0', sizeof(sockaddr));

                struct iovec iov[2] = {{ .iov_base = (void*)&fwd_hdr,
                                         .iov_len = sizeof(fwd_hdr)},
                                       { .iov_base = (void*)buf,
                                         .iov_len = sizeof(buf) }};

                struct msghdr msghdr = { .msg_name = (void*)&sockaddr,
                                         .msg_namelen = sizeof(sockaddr),
                                         .msg_iov = iov,
                                         .msg_iovlen = 2,
                                         .msg_control = NULL,
                                         .msg_controllen = 0,
                                         .msg_flags = 0};

                ssize_t rsize = recvmsg(fd, &msghdr, MSG_DONTWAIT);
                if (rsize < 0)
                {
                    break;
                }

                if (rsize < (ssize_t)sizeof(wrxfwd_t))
                {
                    continue;
                }

                rsize -= sizeof(wrxfwd_t);

                agg->process_packet(buf,
                                    rsize,
                                    fwd_hdr.wlan_idx,
                                    fwd_hdr.antenna,
                                    fwd_hdr.rssi,
                                    fwd_hdr.noise,
                                    ntohs(fwd_hdr.freq),
                                    fwd_hdr.mcs_index,
                                    fwd_hdr.bandwidth,
                                    &sockaddr);
            }
        }
    }
}

#ifndef __WFB_RX_SHARED_LIBRARY__
int main(int argc, char* const *argv)
{
    int opt;
    uint8_t radio_port = 0;
    uint32_t link_id = 0;
    uint64_t epoch = 0;
    int log_interval = 1000;
    int client_port = 5600;
    int srv_port = 0;
    string client_addr = "127.0.0.1";
    rx_mode_t rx_mode = LOCAL;
    int rcv_buf = 0;
    int snd_buf = 0;
    uint8_t local_node_id = 0;
    int plaintext_fec_k = -1;
    int plaintext_fec_n = -1;

    string keypair = "rx.key";
    string unix_socket = "";
    set<uint8_t> known_client_node_ids;

    while ((opt = getopt(argc, argv, "K:N:m:fa:c:u:U:p:l:i:e:R:s:k:n:")) != -1) {
        switch (opt) {
        case 'K':
            keypair = optarg;
            break;
        case 'N':
        {
            int parsed_node_id = atoi(optarg);
            if (parsed_node_id < 0 || parsed_node_id > 255)
            {
                WFB_ERR("Invalid local node_id: %s\n", optarg);
                exit(1);
            }
            local_node_id = static_cast<uint8_t>(parsed_node_id);
            break;
        }
        case 'm':
            known_client_node_ids = parse_known_client_node_ids(optarg);
            break;
        case 'f':
            rx_mode = FORWARDER;
            break;
        case 'a':
            rx_mode = AGGREGATOR;
            srv_port = atoi(optarg);
            break;
        case 'c':
            client_addr = string(optarg);
            break;
        case 'u':
            client_port = atoi(optarg);
            break;
        case 'U':
            unix_socket = string(optarg);
            break;
        case 'p':
            radio_port = atoi(optarg);
            break;
        case 'R':
            rcv_buf = atoi(optarg);
            break;
        case 's':
            snd_buf = atoi(optarg);
            break;
        case 'k':
            plaintext_fec_k = atoi(optarg);
            break;
        case 'n':
            plaintext_fec_n = atoi(optarg);
            break;
        case 'l':
            log_interval = atoi(optarg);
            break;
        case 'i':
            link_id = ((uint32_t)atoi(optarg)) & 0xffffff;
            break;
        case 'e':
            epoch = atoll(optarg);
            break;
        default: /* '?' */
        show_usage:
            WFB_INFO("Local RX: %s [-K rx_key] [-N local_node_id] [-m known_client_node_ids] { [-c client_addr] [-u client_port] | [-U unix_socket] } [-p radio_port]\n"
                     "             [-R rcv_buf] [-s snd_buf] [-l log_interval] [-e epoch] [-i link_id] [-k fec_k] [-n fec_n] interface1 [interface2] ...\n", argv[0]);
            WFB_INFO("RX forwarder: %s -f [-c client_addr] [-u client_port] [-p radio_port]  [-R rcv_buf] [-s snd_buf]\n"
                     "                    [-i link_id] interface1 [interface2] ...\n", argv[0]);
            WFB_INFO("RX aggregator: %s -a server_port [-K rx_key] [-N local_node_id] [-m known_client_node_ids] { [-c client_addr] [-u client_port] | [-U unix_socket] } [-R rcv_buf]\n"
                     "                                 [-s snd_buf] [-l log_interval] [-p radio_port] [-e epoch] [-i link_id] [-k fec_k] [-n fec_n]\n", argv[0]);
            WFB_INFO("Default: K='%s', local_node_id=%u, connect=%s:%d, link_id=0x%06x, radio_port=%u, epoch=%" PRIu64 ", log_interval=%d, rcv_buf=system_default, snd_buf=system_default, plaintext_fec=%d/%d\n", keypair.c_str(), local_node_id, client_addr.c_str(), client_port, link_id, radio_port, epoch, log_interval, plaintext_fec_k, plaintext_fec_n);
            WFB_INFO("WFB-ng version %s, FEC: %s\n", WFB_VERSION, zfex_opt);
            WFB_INFO("WFB-ng home page: <http://wfb-ng.org>\n");
            exit(1);
        }
    }

    {
        int fd;
        int c;

        if ((fd = open("/dev/random", O_RDONLY)) != -1) {
            if (ioctl(fd, RNDGETENTCNT, &c) == 0 && c < 160) {
                WFB_ERR("This system doesn't provide enough entropy to quickly generate high-quality random numbers.\n"
                        "Installing the rng-utils/rng-tools, jitterentropy or haveged packages may help.\n"
                        "On virtualized Linux environments, also consider using virtio-rng.\n"
                        "The service will not start until enough entropy has been collected.\n");
            }
            (void) close(fd);
        }
    }

    if (sodium_init() < 0)
    {
        WFB_ERR("Libsodium init failed\n");
        return 1;
    }

    try
    {
        uint32_t channel_id = (link_id << 8) + radio_port;
        const bool trusted_plaintext = (keypair == WFB_TRUSTED_PLAINTEXT_KEYPAIR);

        if (trusted_plaintext && (plaintext_fec_k < 1 || plaintext_fec_n < 1))
        {
            throw runtime_error("trusted_plaintext requires -k/-n for rx");
        }

        // WiFi interface(s) are required for all modes except aggregator
        if(rx_mode == AGGREGATOR)
        {
            if (optind > argc) goto show_usage;
        }
        else
        {
            if (optind >= argc) goto show_usage;
        }

        unique_ptr<BaseAggregator> agg;
        unique_ptr<TokenEventDatagramListener> token_event_listener;

        switch(rx_mode)
        {
        case LOCAL:
        case AGGREGATOR:
            if(unix_socket.length() > 0)
            {
                agg = unique_ptr<AggregatorUNIX>(new AggregatorUNIX(unix_socket, keypair, epoch, channel_id, snd_buf, local_node_id,
                                                                    trusted_plaintext, plaintext_fec_k, plaintext_fec_n));
                token_event_listener = unique_ptr<TokenEventDatagramListener>(new TokenEventDatagramListener(unix_socket));
                static_cast<Aggregator*>(agg.get())->set_token_control_listener(token_event_listener.get());
            }
            else
            {
                agg = unique_ptr<AggregatorUDPv4>(new AggregatorUDPv4(client_addr, client_port, keypair, epoch, channel_id, snd_buf, local_node_id,
                                                                      trusted_plaintext, plaintext_fec_k, plaintext_fec_n));
            }
            break;

        case FORWARDER:
            agg = unique_ptr<Forwarder>(new Forwarder(client_addr, client_port, snd_buf));
            break;

        default:
            throw runtime_error(string_format("Unknown rx_mode=%d", rx_mode));
        }
        if (rx_mode != FORWARDER && !known_client_node_ids.empty())
        {
            static_cast<Aggregator*>(agg.get())->set_known_client_node_ids(known_client_node_ids);
        }

        if(rx_mode == AGGREGATOR)
        {
            network_loop(srv_port, agg, log_interval, rcv_buf);
        }
        else
        {
            radio_loop(argc, argv, optind, channel_id, agg, log_interval, rcv_buf);
        }
    }
    catch(runtime_error &e)
    {
        WFB_ERR("Error: %s\n", e.what());
        exit(1);
    }
    return 0;
}

#endif
